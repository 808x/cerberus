"""
src/task1_classifier/dataset.py

Builds a labeled feature dataset from the three-class adversarial data:
  data/real/         -> label 0 (real)
  data/fake_synth/   -> label 1 (synthetic fake)
  data/fake_distort/ -> label 2 (distorted-real fake)

Uses the rich feature extractor from feature_extraction.py.
"""

import glob
import json
import os

import joblib
import numpy as np
import torch
from feature_extraction import extract_features, feature_vector
from torch.utils.data import Dataset

LABEL_REAL = 0
LABEL_FAKE_SYNTH = 1
LABEL_FAKE_DISTORT = 2

LABEL_DIRS = {
    "real": LABEL_REAL,
    "fake_synth": LABEL_FAKE_SYNTH,
    "fake_distort": LABEL_FAKE_DISTORT,
}


def _extract_vector(audio_path: str) -> np.ndarray:
    feats = extract_features(audio_path)
    return feature_vector(feats)


def _extract_labeled(args):
    """Helper for parallel extraction: returns (path, label, vector)."""
    path, label = args
    try:
        vec = _extract_vector(path)
        return path, label, vec
    except Exception as e:
        print(f"[skip] {path}: {e}")
        return None


def build_raw_dataset(
    data_root: str = "data", use_cache: bool = True, n_jobs: int = -1
):
    """Returns (X: np.ndarray [N, D], y: np.ndarray [N], paths: list[str])."""
    cache_file = os.path.join(data_root, "_feature_cache.npz")

    if use_cache and os.path.exists(cache_file):
        print(f"Loading cached features from {cache_file}")
        cache = np.load(cache_file, allow_pickle=True)
        return cache["X"], cache["y"], list(cache["paths"])

    tasks = []
    for subdir, label in LABEL_DIRS.items():
        full_dir = os.path.join(data_root, subdir)
        if not os.path.isdir(full_dir):
            print(f"[warn] Directory not found: {full_dir}")
            continue
        files = sorted(glob.glob(os.path.join(full_dir, "*.wav")))
        print(f"[label {label}] {subdir}: {len(files)} files")
        tasks.extend([(f, label) for f in files])

    if not tasks:
        raise RuntimeError(
            f"No data found under {data_root}. Run Task 0 dataset builder first."
        )
    print(f"Extracting features for {len(tasks)} files using {n_jobs} workers...")
    results = joblib.Parallel(n_jobs=n_jobs, verbose=5)(
        joblib.delayed(_extract_labeled)(t) for t in tasks
    )

    paths, labels, X = [], [], []
    for r in results:
        if r is not None:
            paths.append(r[0])
            labels.append(r[1])
            X.append(r[2])

    if len(X) == 0:
        raise RuntimeError("No features could be extracted.")

    X = np.stack(X)
    y = np.array(labels, dtype=np.int64)

    if use_cache:
        print(f"Saving feature cache to {cache_file}")
        np.savez(cache_file, X=X, y=y, paths=np.array(paths))

    return X, y, paths


def fit_scaler(X: np.ndarray) -> dict:
    mean = X.mean(axis=0)
    std = X.std(axis=0)
    std[std < 1e-6] = 1e-6
    return {"mean": mean.tolist(), "std": std.tolist()}


def apply_scaler(X: np.ndarray, scaler: dict) -> np.ndarray:
    mean = np.array(scaler["mean"], dtype=np.float32)
    std = np.array(scaler["std"], dtype=np.float32)
    return (X - mean) / std


def save_scaler(scaler: dict, path: str):
    with open(path, "w") as f:
        json.dump(scaler, f, indent=2)


def load_scaler(path: str) -> dict:
    with open(path, "r") as f:
        return json.load(f)


class SpoofDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]
