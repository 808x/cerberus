"""
agents/llm_interface.py

Single point of contact between the agent graph and whatever LLM backend
you choose. This keeps graph.py clean - it just calls `generate_reasoning(...)`
without caring whether that's Claude, GPT, a local Ollama model, or a stub.

SWAP-IN POINT: implement `_call_anthropic`, `_call_openai`, or `_call_ollama`
once you've picked a backend, then set `llm.provider` in config.yaml.
"""

import re
from typing import Optional


def generate_reasoning(
    prompt: str,
    provider: str = "stub",
    model: str = "",
    temperature: float = 0.2,
    max_tokens: int = 500,
) -> str:
    if provider == "stub":
        return _call_stub(prompt)
    elif provider == "anthropic":
        return _call_anthropic(prompt, model, temperature, max_tokens)
    elif provider == "openai":
        return _call_openai(prompt, model, temperature, max_tokens)
    elif provider == "ollama":
        return _call_ollama(prompt, model, temperature, max_tokens)
    else:
        raise ValueError(f"Unknown LLM provider: {provider}")


def _extract_value(prompt: str, key: str) -> Optional[str]:
    """Extract a key: value line from the prompt."""
    pattern = rf"^-\s*{re.escape(key)}:\s*(.+)$"
    match = re.search(pattern, prompt, re.MULTILINE)
    if match:
        return match.group(1).strip()
    return None


def _extract_feature_value(prompt: str, key: str) -> Optional[str]:
    """Extract a numeric feature value from the reasoning trace text."""
    pattern = rf"{re.escape(key)}=([0-9.]+)"
    match = re.search(pattern, prompt)
    if match:
        return match.group(1)
    return None


def _call_stub(prompt: str) -> str:
    """
    Deterministic, feature-grounded stand-in so the pipeline runs with zero
    API keys. It parses the evidence trace embedded in the prompt and writes a
    concise explanation tied to actual numbers. Replace with a real LLM call
    for more fluent, open-ended reasoning.
    """
    verdict = _extract_value(prompt, "Verdict") or "UNKNOWN"
    risk = _extract_value(prompt, "Risk level") or "UNKNOWN"
    confidence_str = _extract_value(prompt, "Confidence") or "0"
    confidence = float(confidence_str) if confidence_str else 0.0
    attack = _extract_value(prompt, "Attack type guess") or None
    if attack in ("None", "null", "n/a"):
        attack = None
    model_used = _extract_value(prompt, "Classifier used") or "classifier"
    predicted_class = _extract_value(prompt, "Classifier predicted class") or ""
    class_probs = _extract_value(prompt, "Classifier class probabilities") or ""
    recommended_action = (
        _extract_value(prompt, "Recommended action") or "Review the evidence trace."
    )
    is_ood_str = _extract_value(prompt, "Out-of-distribution") or "False"
    is_ood = is_ood_str.lower().startswith("true")
    degradation_risk = _extract_value(prompt, "Degradation risk") or "UNKNOWN"

    # Pull a few key feature values if present
    pitch = _extract_feature_value(prompt, "pitch_mean")
    flatness = _extract_feature_value(prompt, "spectral_flatness_mean")
    hf = _extract_feature_value(prompt, "high_freq_energy_ratio")

    sentences = []

    if is_ood or verdict == "INSUFFICIENT_EVIDENCE":
        sentences.append(
            "The sample could not be reliably classified because it is outside "
            "the distribution the model was trained on (too short, too silent, or "
            "otherwise unlike typical speech)."
        )
        sentences.append(recommended_action)
        return " ".join(sentences)

    sentences.append(
        f"The {model_used} model predicted class {predicted_class} "
        f"with class probabilities {class_probs}, mapping to a "
        f"verdict of {verdict} with {risk} risk and confidence {confidence}."
    )

    if attack:
        sentences.append(
            f"The feature profile matches the known '{attack}' attack signature, "
            f"strengthening the suspicion that this audio was synthetically generated."
        )
    elif verdict in ("FAKE", "LIKELY_FAKE"):
        sentences.append(
            "No specific known attack signature matched, but the overall acoustic "
            "profile is consistent with synthetic or manipulated speech."
        )

    if flatness and hf:
        sentences.append(
            f"Spectral flatness ({flatness}) and high-frequency energy ratio "
            f"({hf}) are the main acoustic cues driving this assessment."
        )
    elif pitch:
        sentences.append(
            f"Pitch and timbral features (pitch_mean={pitch}Hz) are the main "
            f"acoustic cues driving this assessment."
        )

    if degradation_risk == "HIGH":
        sentences.append(
            "The classifier's historical performance drops under similar acoustic "
            "conditions, so this verdict should be treated as tentative."
        )

    sentences.append(recommended_action)

    return " ".join(sentences)


def _call_anthropic(
    prompt: str, model: str, temperature: float, max_tokens: int
) -> str:
    """Requires: pip install anthropic, and ANTHROPIC_API_KEY set in env."""
    import anthropic

    client = anthropic.Anthropic()
    response = client.messages.create(
        model=model or "claude-sonnet-4-6",
        max_tokens=max_tokens,
        temperature=temperature,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")


def _call_openai(prompt: str, model: str, temperature: float, max_tokens: int) -> str:
    """Requires: pip install openai, and OPENAI_API_KEY set in env."""
    from openai import OpenAI

    client = OpenAI()
    response = client.chat.completions.create(
        model=model or "gpt-4o-mini",
        max_tokens=max_tokens,
        temperature=temperature,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content


def _call_ollama(prompt: str, model: str, temperature: float, max_tokens: int) -> str:
    """Requires a running local Ollama server (ollama serve) and `requests`."""
    import requests

    resp = requests.post(
        "http://localhost:11434/api/generate",
        json={"model": model or "llama3", "prompt": prompt, "stream": False},
    )
    return resp.json().get("response", "")
