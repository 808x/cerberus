"""
src/task0_cloning/build_adversarial_dataset.py

Builds the three-class adversarial dataset used by Task 1.

Classes:
  real          -> original clean real recordings (chunked)
  fake_synth    -> XTTS synthetic clones (chunked)
  fake_distort  -> real recordings with adversarial distortions (chunked)

Input:
  - cbs_adi/Data/Real/        team member real voices
  - cbs_adi/Data/Clones/      XTTS clones

Output:
  - data/real/*.wav
  - data/fake_synth/*.wav
  - data/fake_distort/*.wav

The script also normalizes filenames (Reyal -> Real), converts .ogg to .wav,
and removes duplicates.
"""

import argparse
import os
import re
import shutil
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf
from augmentations import distort

TARGET_SR = 16000


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--real-dir", default="../cbs_adi/Data/Real")
    p.add_argument("--clone-dir", default="../cbs_adi/Data/Clones")
    p.add_argument("--out-dir", default="data")
    p.add_argument(
        "--external-real-dir",
        default=None,
        help="Optional directory of additional real audio (e.g. LibriSpeech)",
    )
    p.add_argument(
        "--max-external-real",
        type=int,
        default=100,
        help="Max number of external real files to include",
    )
    p.add_argument("--chunk-sec", type=float, default=3.5)
    p.add_argument("--hop-sec", type=float, default=1.75)
    p.add_argument(
        "--n-distort-per-real",
        type=int,
        default=3,
        help="How many distorted variants to generate per real chunk",
    )
    p.add_argument("--target-sr", type=int, default=TARGET_SR)
    p.add_argument(
        "--clear", action="store_true", help="Clear output directories before writing"
    )
    return p.parse_args()


def normalize_filename(name: str) -> str:
    """Clean up filenames: Reyal -> Real, lowercase, no special chars."""
    name = name.replace("Reyal", "Real").replace("REYAL", "Real")
    name = re.sub(r"[^\w\s.-]", "", name)
    name = re.sub(r"\s+", "_", name).strip("_")
    name = re.sub(r"_+", "_", name)
    return name.lower()


def prepare_real_sources(real_dir: str, temp_dir: str) -> list:
    """
    Copy/convertt all real audio into a clean temp folder with normalized names.
    Prefers .wav; converts .ogg if no .wav counterpart exists.
    """
    os.makedirs(temp_dir, exist_ok=True)
    files = sorted(Path(real_dir).iterdir())

    # Group by normalized stem
    by_stem = {}
    for f in files:
        if f.suffix.lower() not in (".wav", ".ogg"):
            continue
        stem = normalize_filename(f.stem)
        by_stem.setdefault(stem, []).append(f)

    sources = []
    for stem, paths in by_stem.items():
        # Prefer wav
        wavs = [p for p in paths if p.suffix.lower() == ".wav"]
        chosen = wavs[0] if wavs else paths[0]
        out_path = os.path.join(temp_dir, f"{stem}.wav")

        y, sr = librosa.load(str(chosen), sr=TARGET_SR, mono=True)
        sf.write(out_path, y, TARGET_SR)
        sources.append(out_path)

    return sources


def chunk_audio(audio_path: str, chunk_sec: float, hop_sec: float) -> list:
    """Split an audio file into overlapping chunks. Returns list of (y, sr) tuples."""
    y, sr = librosa.load(audio_path, sr=TARGET_SR, mono=True)
    if len(y) == 0:
        return []

    chunk_len = int(chunk_sec * sr)
    hop_len = int(hop_sec * sr)

    chunks = []
    for start in range(0, len(y) - chunk_len + 1, hop_len):
        end = start + chunk_len
        chunk = y[start:end]
        # Skip near-silent chunks
        if np.max(np.abs(chunk)) < 0.01:
            continue
        chunks.append(chunk)

    # If file is shorter than chunk_len, pad and use the whole thing
    if not chunks and len(y) > sr * 0.5:
        pad = chunk_len - len(y)
        chunks.append(np.pad(y, (0, pad), mode="constant"))

    return chunks


def save_chunks(chunks: list, out_dir: str, prefix: str):
    """Save chunks as numbered wav files."""
    os.makedirs(out_dir, exist_ok=True)
    paths = []
    for i, chunk in enumerate(chunks):
        if not np.isfinite(chunk).all():
            print(f"  [skip {prefix}_{i:04d}] non-finite values")
            continue
        path = os.path.join(out_dir, f"{prefix}_{i:04d}.wav")
        # Normalize peak
        peak = np.max(np.abs(chunk))
        if peak > 0:
            chunk = chunk / peak
        try:
            sf.write(path, chunk, TARGET_SR)
            paths.append(path)
        except Exception as e:
            print(f"  [skip {prefix}_{i:04d}] write failed: {e}")
    return paths


def build_dataset(args):
    project_root = Path(__file__).resolve().parents[2]
    real_dir = project_root / args.real_dir
    clone_dir = project_root / args.clone_dir
    out_dir = project_root / args.out_dir

    real_out = out_dir / "real"
    fake_synth_out = out_dir / "fake_synth"
    fake_distort_out = out_dir / "fake_distort"

    if args.clear:
        for d in (real_out, fake_synth_out, fake_distort_out):
            if d.exists():
                shutil.rmtree(d)

    for d in (real_out, fake_synth_out, fake_distort_out):
        d.mkdir(parents=True, exist_ok=True)

    temp_dir = out_dir / "_temp_real_sources"
    temp_dir.mkdir(parents=True, exist_ok=True)

    print("Preparing real sources...")
    real_sources = prepare_real_sources(str(real_dir), str(temp_dir))
    print(f"  -> {len(real_sources)} unique real sources")

    # Optional external real audio (e.g. LibriSpeech)
    if args.external_real_dir:
        ext_dir = project_root / args.external_real_dir
        if ext_dir.exists():
            ext_files = sorted(ext_dir.glob("*.wav"))[: args.max_external_real]
            print(f"  -> adding {len(ext_files)} external real sources from {ext_dir}")
            real_sources.extend(str(f) for f in ext_files)
        else:
            print(f"  [warn] external real dir not found: {ext_dir}")

    # ------------------------------------------------------------------
    # 1. real chunks
    # ------------------------------------------------------------------
    print("\nChunking real audio...")
    real_count = 0
    for src in real_sources:
        stem = Path(src).stem
        chunks = chunk_audio(src, args.chunk_sec, args.hop_sec)
        save_chunks(chunks, str(real_out), f"real_{stem}")
        real_count += len(chunks)
    print(f"  -> {real_count} real chunks")

    # ------------------------------------------------------------------
    # 2. fake_synth chunks from clones
    # ------------------------------------------------------------------
    print("\nChunking synthetic clones...")
    clone_files = sorted(clone_dir.glob("*.wav"))
    synth_count = 0
    for clone_path in clone_files:
        stem = normalize_filename(clone_path.stem)
        chunks = chunk_audio(str(clone_path), args.chunk_sec, args.hop_sec)
        save_chunks(chunks, str(fake_synth_out), f"synth_{stem}")
        synth_count += len(chunks)
    print(f"  -> {synth_count} fake_synth chunks")

    # ------------------------------------------------------------------
    # 3. fake_distort = distorted real chunks
    # ------------------------------------------------------------------
    print("\nGenerating adversarial distortions of real audio...")
    distort_count = 0
    total_real_chunks = sum(
        len(chunk_audio(src, args.chunk_sec, args.hop_sec)) for src in real_sources
    )
    total_distort = total_real_chunks * args.n_distort_per_real
    processed = 0
    for src in real_sources:
        stem = Path(src).stem
        chunks = chunk_audio(src, args.chunk_sec, args.hop_sec)
        for i, chunk in enumerate(chunks):
            for j in range(args.n_distort_per_real):
                seed = abs(hash(f"{stem}_{i}_{j}")) % (2**31)
                distorted = distort(chunk, TARGET_SR, seed, n_ops=3)
                if not np.isfinite(distorted).all():
                    print(f"  [skip distort_{stem}_{i:04d}_v{j}] non-finite values")
                    continue
                out_path = fake_distort_out / f"distort_{stem}_{i:04d}_v{j}.wav"
                sf.write(out_path, distorted, TARGET_SR)
                distort_count += 1
                processed += 1
                if processed % 50 == 0 or processed == total_distort:
                    print(f"  ... {processed}/{total_distort} distortions written")
    print(f"  -> {distort_count} fake_distort chunks")

    # Cleanup temp
    shutil.rmtree(temp_dir, ignore_errors=True)

    print("\nDataset build complete.")
    print(f"  real:        {real_count}")
    print(f"  fake_synth:  {synth_count}")
    print(f"  fake_distort:{distort_count}")
    print(f"  total:       {real_count + synth_count + distort_count}")


if __name__ == "__main__":
    args = parse_args()
    build_dataset(args)
