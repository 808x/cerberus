"""
agents/threat_assessment.py

Converts the classifier's numeric output + secondary check results into a
structured, human-meaningful threat assessment: risk level + best-guess
attack type. This is what makes the output useful to a security analyst
rather than just a probability number.

Now also incorporates:
  - out-of-distribution / insufficient-evidence signals
  - Task 3 robustness context (expected accuracy at estimated SNR)
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ThreatAssessment:
    risk_level: str  # LOW | MEDIUM | HIGH | CRITICAL | UNKNOWN
    verdict: str  # REAL | LIKELY_REAL | LIKELY_FAKE | FAKE | INSUFFICIENT_EVIDENCE
    attack_type_guess: Optional[str]
    confidence: float
    recommended_action: str


def assess(
    fake_probability: float,
    matched_attack_type: Optional[str],
    reliable_sample: bool,
    is_ood: bool = False,
    robustness_reliability: float = 1.0,
    degradation_risk: str = "UNKNOWN",
) -> ThreatAssessment:
    """
    Produce a verdict from all available evidence.

    Args:
        fake_probability: primary classifier score (0=real, 1=fake).
        matched_attack_type: name from known_attack_signature_check, or None.
        reliable_sample: False if noise/robustness check flagged the sample.
        is_ood: True if out_of_distribution_check flagged the sample.
        robustness_reliability: 0-1 score from Task 3 report.
        degradation_risk: LOW/MEDIUM/HIGH/UNKNOWN classifier degradation risk.
    """
    # If the sample is OOD, do not force a verdict.
    if is_ood:
        return ThreatAssessment(
            risk_level="UNKNOWN",
            verdict="INSUFFICIENT_EVIDENCE",
            attack_type_guess=None,
            confidence=0.0,
            recommended_action=(
                "Re-record or provide a longer/cleaner sample; the current clip "
                "is too far from the training distribution for a reliable decision."
            ),
        )

    # Effective confidence: combine classifier confidence with robustness reliability.
    raw_confidence = (
        abs(fake_probability - 0.5) * 2
    )  # 0 = totally ambiguous, 1 = fully confident
    effective_confidence = raw_confidence * robustness_reliability

    if fake_probability >= 0.85:
        verdict = "FAKE"
        risk_level = "CRITICAL" if matched_attack_type else "HIGH"
    elif fake_probability >= 0.5:
        verdict = "LIKELY_FAKE"
        risk_level = "HIGH" if reliable_sample else "MEDIUM"
    elif fake_probability >= 0.15:
        verdict = "LIKELY_REAL"
        risk_level = "MEDIUM" if not reliable_sample else "LOW"
    else:
        verdict = "REAL"
        risk_level = "LOW"

    # Downgrade confidence / risk if the classifier is known to degrade under
    # similar conditions.
    if degradation_risk == "HIGH" and verdict in ("FAKE", "LIKELY_FAKE"):
        risk_level = "MEDIUM" if risk_level == "HIGH" else risk_level
        recommended_action = (
            "Classifier performance is known to degrade under conditions similar "
            "to this sample. Treat the verdict as tentative and consider manual review."
        )
    elif verdict == "INSUFFICIENT_EVIDENCE":
        recommended_action = "Provide a clearer sample for re-analysis."
    elif verdict in ("FAKE", "LIKELY_FAKE"):
        recommended_action = (
            "Flag for security review and verify speaker identity out-of-band."
        )
    elif verdict in ("REAL", "LIKELY_REAL"):
        recommended_action = (
            "No immediate action required; continue standard monitoring."
        )
    else:
        recommended_action = "Review the evidence trace."

    return ThreatAssessment(
        risk_level=risk_level,
        verdict=verdict,
        attack_type_guess=matched_attack_type,
        confidence=round(effective_confidence, 3),
        recommended_action=recommended_action,
    )
