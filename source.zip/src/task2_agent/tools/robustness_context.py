"""
tools/robustness_context.py

Task 2 agentic enhancement: consume the Task 3 robustness report so the agent
knows how much to trust the primary classifier under different conditions.

The report (reports/task3_robustness.json) contains clean-baseline accuracy/F1
and accuracy/F1 at several SNR levels. This module:
  1. Loads that report if it exists.
  2. Estimates an effective SNR for the current sample from its silence ratio
     and spectral flatness (cheap proxies — no ground-truth clean reference).
  3. Returns a reliability score + expected accuracy degradation that the
     threat-assessment node can fold into its verdict and explanation.
"""

import json
import os
from dataclasses import dataclass
from typing import Optional

from tools.feature_extraction import AudioFeatures


@dataclass
class RobustnessContext:
    report_available: bool
    estimated_snr_db: float
    reliability_score: float  # 0.0 = unreliable, 1.0 = fully reliable
    expected_accuracy: Optional[float]
    expected_f1: Optional[float]
    degradation_risk: str  # LOW | MEDIUM | HIGH
    reason: str


def _load_report(path: str) -> Optional[dict]:
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def _estimate_snr(features: AudioFeatures) -> float:
    """
    Cheap SNR estimate from heuristics. This is intentionally approximate —
    it lets the agent reason about robustness without requiring a clean
    reference signal. Normal speech with pauses should still map to the
    clean/high-SNR regime; only strong noise indicators should pull it down.
    """
    # Start from a clean baseline assumption
    estimated = 30.0

    # Spectral flatness is the best cheap noise proxy: noisy signals are flatter.
    # Typical clean speech flatness is ~0.02-0.08; very flat signals (>0.15)
    # suggest significant noise.
    if features.spectral_flatness_mean > 0.15:
        estimated -= (features.spectral_flatness_mean - 0.15) * 40.0

    # Only heavily penalize extreme silence ratios (e.g. mostly silence,
    # not normal speech pauses). Most clean utterances have silence_ratio < 0.5.
    if features.silence_ratio > 0.6:
        estimated -= (features.silence_ratio - 0.6) * 30.0

    # Very short clips have less signal to work with
    if features.duration_sec < 1.0:
        estimated -= 10.0

    return max(0.0, min(40.0, estimated))


def _lookup_robustness(report: dict, snr_db: float) -> dict:
    """Pick the report entry closest to the estimated SNR."""
    keys = [
        "clean_baseline",
        "noise_snr_20db",
        "noise_snr_10db",
        "noise_snr_5db",
        "noise_snr_0db",
    ]
    snr_map = {
        "clean_baseline": 30.0,
        "noise_snr_20db": 20.0,
        "noise_snr_10db": 10.0,
        "noise_snr_5db": 5.0,
        "noise_snr_0db": 0.0,
    }

    best_key = "clean_baseline"
    best_dist = abs(snr_db - snr_map["clean_baseline"])
    for k in keys:
        dist = abs(snr_db - snr_map[k])
        if dist < best_dist:
            best_dist = dist
            best_key = k

    return report.get(best_key, {})


def get_robustness_context(
    features: AudioFeatures,
    robustness_report_path: str,
) -> RobustnessContext:
    report = _load_report(robustness_report_path)
    snr_db = _estimate_snr(features)

    if report is None:
        return RobustnessContext(
            report_available=False,
            estimated_snr_db=snr_db,
            reliability_score=0.75,  # neutral when we have no report
            expected_accuracy=None,
            expected_f1=None,
            degradation_risk="UNKNOWN",
            reason="No Task 3 robustness report found; assuming neutral reliability.",
        )

    entry = _lookup_robustness(report, snr_db)
    acc = entry.get("accuracy")
    f1 = entry.get("f1") or entry.get("weighted_f1")

    if acc is None:
        return RobustnessContext(
            report_available=True,
            estimated_snr_db=snr_db,
            reliability_score=0.75,
            expected_accuracy=None,
            expected_f1=None,
            degradation_risk="UNKNOWN",
            reason="Robustness report exists but has no accuracy entry for this condition.",
        )

    # Reliability: scale expected accuracy to 0-1, with a floor so the agent
    # still has some confidence even in bad conditions.
    reliability = max(0.25, min(1.0, acc))

    if acc >= 0.85:
        risk = "LOW"
    elif acc >= 0.65:
        risk = "MEDIUM"
    else:
        risk = "HIGH"

    return RobustnessContext(
        report_available=True,
        estimated_snr_db=snr_db,
        reliability_score=round(reliability, 3),
        expected_accuracy=round(acc, 3),
        expected_f1=round(f1, 3) if f1 is not None else None,
        degradation_risk=risk,
        reason=(
            f"Task 3 robustness report predicts ~{acc:.1%} accuracy at "
            f"~{snr_db:.0f} dB effective SNR (degradation risk: {risk})."
        ),
    )
