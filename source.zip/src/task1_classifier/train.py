"""
src/task1_classifier/train.py

Trains the 3-class anti-spoofing classifier on the adversarial dataset.

Classes:
  0 = real
  1 = fake_synthetic
  2 = fake_distorted

Usage:
    python src/task1_classifier/train.py --data-root data --epochs 60
"""

import argparse
import json
import os
import sys

import numpy as np
import torch
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader

sys.path.append(os.path.dirname(__file__))
from dataset import (
    SpoofDataset,
    apply_scaler,
    build_raw_dataset,
    fit_scaler,
    save_scaler,
)
from model import build_model

CLASS_NAMES = ["real", "fake_synth", "fake_distort"]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", default="data")
    p.add_argument("--out", default="models/task1_classifier.pt")
    p.add_argument("--scaler-out", default="models/task1_scaler.json")
    p.add_argument("--epochs", type=int, default=60)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--lr", type=float, default=5e-4)
    p.add_argument("--hidden", type=int, default=256)
    p.add_argument("--dropout", type=float, default=0.4)
    p.add_argument("--val-split", type=float, default=0.2)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument(
        "--n-jobs",
        type=int,
        default=-1,
        help="Parallel workers for feature extraction (-1 = all cores)",
    )
    return p.parse_args()


def main():
    args = parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    print(f"Extracting features from {args.data_root} ...")
    X, y, paths = build_raw_dataset(args.data_root, n_jobs=args.n_jobs)
    print(f"Dataset size: {len(y)} samples")
    for i, name in enumerate(CLASS_NAMES):
        print(f"  {name}: {int((y == i).sum())}")

    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=args.val_split, random_state=args.seed, stratify=y
    )

    scaler = fit_scaler(X_train)
    X_train = apply_scaler(X_train, scaler)
    X_val = apply_scaler(X_val, scaler)

    train_loader = DataLoader(
        SpoofDataset(X_train, y_train), batch_size=args.batch_size, shuffle=True
    )
    val_loader = DataLoader(
        SpoofDataset(X_val, y_val), batch_size=args.batch_size, shuffle=False
    )

    in_dim = X.shape[1]
    model = build_model(
        in_dim=in_dim, hidden=args.hidden, dropout=args.dropout, n_classes=3
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-3)
    criterion = torch.nn.CrossEntropyLoss()
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=0.5, patience=5
    )

    best_val_f1 = -1.0
    best_state = None
    best_metrics = None

    for epoch in range(1, args.epochs + 1):
        model.train()
        train_loss = 0.0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            logits = model(xb)
            loss = criterion(logits, yb)
            loss.backward()
            optimizer.step()
            train_loss += loss.item() * xb.size(0)
        train_loss /= len(train_loader.dataset)

        model.eval()
        all_probs, all_preds, all_labels = [], [], []
        with torch.no_grad():
            for xb, yb in val_loader:
                xb = xb.to(device)
                logits = model(xb)
                probs = torch.softmax(logits, dim=1).cpu().numpy()
                preds = logits.argmax(dim=1).cpu().numpy()
                all_probs.extend(probs)
                all_preds.extend(preds)
                all_labels.extend(yb.numpy())

        all_preds = np.array(all_preds)
        all_labels = np.array(all_labels)

        acc = accuracy_score(all_labels, all_preds)
        precision, recall, f1, _ = precision_recall_fscore_support(
            all_labels, all_preds, average="weighted", zero_division=0
        )
        per_class_f1 = precision_recall_fscore_support(
            all_labels, all_preds, labels=[0, 1, 2], zero_division=0
        )[2]

        print(
            f"Epoch {epoch:3d}/{args.epochs} | train_loss={train_loss:.4f} | "
            f"val_acc={acc:.3f} val_f1={f1:.3f}"
        )
        for i, name in enumerate(CLASS_NAMES):
            print(f"    {name:12s} f1={per_class_f1[i]:.3f}")

        if f1 >= best_val_f1:
            best_val_f1 = f1
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
            best_metrics = {
                "accuracy": round(float(acc), 4),
                "weighted_f1": round(float(f1), 4),
                "per_class_f1": {
                    name: round(float(per_class_f1[i]), 4)
                    for i, name in enumerate(CLASS_NAMES)
                },
            }

        scheduler.step(f1)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    checkpoint = {
        "state_dict": best_state,
        "in_dim": in_dim,
        "hidden": args.hidden,
        "dropout": args.dropout,
        "n_classes": 3,
        "class_names": CLASS_NAMES,
        "scaler": scaler,
        "val_metrics": best_metrics,
    }
    torch.save(checkpoint, args.out)
    save_scaler(scaler, args.scaler_out)

    print("\nTraining complete.")
    print(f"Best val metrics: {json.dumps(best_metrics, indent=2)}")
    print(f"Checkpoint saved to: {args.out}")


if __name__ == "__main__":
    main()
