"""
src/task0_cloning/augmentations.py

Adversarial audio augmentations used to build the fake_distort class.
All functions operate on 1-D numpy arrays at the target sample rate.
"""

from typing import Callable, List

import librosa
import numpy as np
from scipy import signal


def _set_seed(seed: int):
    return np.random.default_rng(seed)


def _normalize(y: np.ndarray) -> np.ndarray:
    peak = np.max(np.abs(y))
    return y / peak if peak > 0 else y


def add_noise(
    y: np.ndarray, sr: int, snr_db: float, rng: np.random.Generator
) -> np.ndarray:
    sig_power = np.mean(y**2) + 1e-12
    noise_power = sig_power / (10 ** (snr_db / 10))
    noise = rng.normal(0, np.sqrt(noise_power), size=y.shape)
    return _normalize(y + noise)


def add_reverb(
    y: np.ndarray, sr: int, rng: np.random.Generator, rt60: float = 0.3
) -> np.ndarray:
    n_samples = int(rt60 * sr)
    ir = rng.exponential(0.5, size=n_samples) * np.exp(
        -np.linspace(0, rt60 * 6, n_samples)
    )
    ir = ir / (np.sum(np.abs(ir)) + 1e-12)
    y_rev = signal.fftconvolve(y, ir, mode="full")[: len(y)]
    wet = rng.uniform(0.25, 0.55)
    return _normalize(y * (1 - wet) + y_rev * wet)


def compress_clip(y: np.ndarray, sr: int, rng: np.random.Generator) -> np.ndarray:
    threshold = rng.uniform(0.4, 0.7)
    ratio = rng.uniform(2.0, 6.0)
    gain = 1.0 / (threshold + (1 - threshold) / ratio)
    y_comp = np.where(
        np.abs(y) <= threshold,
        y,
        np.sign(y) * (threshold + (np.abs(y) - threshold) / ratio),
    )
    y_comp *= gain
    y_comp = np.tanh(y_comp)
    return _normalize(y_comp)


def pitch_shift(y: np.ndarray, sr: int, n_steps: float) -> np.ndarray:
    return librosa.effects.pitch_shift(y, sr=sr, n_steps=n_steps)


def time_stretch(y: np.ndarray, sr: int, rate: float) -> np.ndarray:
    y_stretch = librosa.effects.time_stretch(y, rate=rate)
    if len(y_stretch) > len(y):
        y_stretch = y_stretch[: len(y)]
    else:
        pad = len(y) - len(y_stretch)
        y_stretch = np.pad(y_stretch, (0, pad), mode="constant")
    return _normalize(y_stretch)


def bandpass_filter(
    y: np.ndarray, sr: int, low: int = 300, high: int = 3400
) -> np.ndarray:
    sos = signal.butter(6, [low, high], btype="band", fs=sr, output="sos")
    return signal.sosfilt(sos, y)


def quantize_pitch(y: np.ndarray, sr: int, rng: np.random.Generator) -> np.ndarray:
    f0, voiced_flag, _ = librosa.pyin(
        y, fmin=librosa.note_to_hz("C2"), fmax=librosa.note_to_hz("C7"), sr=sr
    )
    voiced_f0 = f0[voiced_flag] if voiced_flag is not None else np.array([])
    if len(voiced_f0) == 0 or np.all(np.isnan(voiced_f0)):
        return pitch_shift(y, sr, rng.uniform(-2.0, 2.0))
    median_f0 = float(np.nanmedian(voiced_f0))
    midi = 69 + 12 * np.log2(median_f0 / 440.0)
    n_steps = round(midi) - midi
    return pitch_shift(y, sr, n_steps)


AUGMENTATIONS: List[Callable] = [
    lambda y, sr, rng: add_noise(y, sr, rng.uniform(5, 20), rng),
    lambda y, sr, rng: add_reverb(y, sr, rng),
    lambda y, sr, rng: compress_clip(y, sr, rng),
    lambda y, sr, rng: pitch_shift(y, sr, rng.uniform(-2.5, 2.5)),
    lambda y, sr, rng: time_stretch(y, sr, rng.uniform(0.85, 1.15)),
    lambda y, sr, rng: bandpass_filter(y, sr),
    lambda y, sr, rng: quantize_pitch(y, sr, rng),
]


def distort(y: np.ndarray, sr: int, seed: int, n_ops: int = 3) -> np.ndarray:
    rng = _set_seed(seed)
    ops = rng.choice(AUGMENTATIONS, size=n_ops, replace=False).tolist()
    y_out = y.copy()
    for op in ops:
        y_out = op(y_out, sr, rng)
        y_out = _normalize(y_out)
    return y_out
