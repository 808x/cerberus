"""
src/task2_agent/graph.py

The agentic workflow itself, built as an explicit LangGraph state machine.

Why this counts as "agentic" and not just a fixed pipeline:
  - The graph has a CONDITIONAL edge (`route_after_classification`) — the
    agent decides at runtime whether it has enough evidence, or whether it
    needs to call secondary tools before reaching a verdict.
  - It now also checks whether the sample is out-of-distribution and whether
    the classifier is known to degrade under similar conditions (using Task 3
    robustness report), and factors both into the final verdict.
  - Every step logs WHY it made its decision into `reasoning_trace`, which
    becomes the explainability output.

Run this file directly for a quick CLI test (from the project root):
    python src/task2_agent/graph.py samples/test_sample.wav
"""

import json
import os
import sys
from typing import List, Optional, TypedDict

import yaml

# Make this file runnable both as `python src/task2_agent/graph.py ...`
# and when imported by the Streamlit app (src/task4_demo/app.py)
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))
sys.path.append(_THIS_DIR)  # so "tools.xxx" / "agents.xxx" resolve
sys.path.append(_PROJECT_ROOT)

from agents.llm_interface import generate_reasoning
from agents.threat_assessment import assess
from langgraph.graph import END, StateGraph
from tools.classifier_tool import predict as classifier_predict
from tools.feature_extraction import extract_features
from tools.robustness_context import get_robustness_context
from tools.secondary_checks import (
    known_attack_signature_check,
    noise_robustness_check,
    out_of_distribution_check,
)

# Task 1's full 224-dim feature extractor (used for OOD scaler check)
sys.path.append(os.path.join(_PROJECT_ROOT, "src", "task1_classifier"))
from feature_extraction import (
    extract_features as extract_classifier_features,
)  # noqa: E402
from feature_extraction import (
    feature_vector,
)


# ------------------------------------------------------------------
# 1. Shared state that flows through every node in the graph
# ------------------------------------------------------------------
class AgentState(TypedDict):
    audio_path: str
    config: dict
    features: Optional[dict]
    _features_obj: Optional[object]
    fake_probability: Optional[float]
    class_probs: Optional[dict]
    predicted_class: Optional[int]
    model_name: Optional[str]
    reliable_sample: Optional[bool]
    matched_attack_type: Optional[str]
    is_ood: Optional[bool]
    ood_reason: Optional[str]
    ambiguous: Optional[bool]
    robustness_context: Optional[dict]
    feature_attribution: Optional[dict]
    feature_risks: Optional[dict]
    reasoning_trace: List[str]
    final_output: Optional[dict]


# ------------------------------------------------------------------
# 2. Node functions — each is one autonomous step of the agent
# ------------------------------------------------------------------
def node_extract_features(state: AgentState) -> AgentState:
    cfg = state["config"]["audio"]
    feats = extract_features(
        state["audio_path"], sample_rate=cfg["sample_rate"], n_mfcc=cfg["n_mfcc"]
    )
    state["features"] = feats.to_dict()
    state["reasoning_trace"].append(
        f"Extracted acoustic features (pitch_mean={feats.pitch_mean:.1f}Hz, "
        f"spectral_flatness={feats.spectral_flatness_mean:.3f}, "
        f"high_freq_energy_ratio={feats.high_freq_energy_ratio:.3f})."
    )
    state["_features_obj"] = feats
    return state


def node_out_of_distribution_check(state: AgentState) -> AgentState:
    """Early sanity check: is this sample even in the training distribution?"""
    cfg = state["config"]
    scaler_path = cfg["paths"].get("classifier_scaler")
    if scaler_path and not os.path.isabs(scaler_path):
        scaler_path = os.path.join(_PROJECT_ROOT, scaler_path)

    thresholds = cfg.get("thresholds", {})
    z_threshold = thresholds.get("ood_z_threshold", 4.0)

    # Build the same 224-dim vector the classifier uses for the scaler check
    full_feats = extract_classifier_features(state["audio_path"])
    full_vector = feature_vector(full_feats)

    result = out_of_distribution_check(
        state["_features_obj"],
        scaler_path=scaler_path,
        z_threshold=z_threshold,
        full_feature_vector=full_vector,
    )
    state["is_ood"] = result["is_ood"]
    state["ood_reason"] = result["reason"]
    state["reasoning_trace"].append(f"OOD check: {result['reason']}")
    return state


def node_classify(state: AgentState) -> AgentState:
    checkpoint = state["config"]["paths"]["classifier_checkpoint"]
    if not os.path.isabs(checkpoint):
        checkpoint = os.path.join(_PROJECT_ROOT, checkpoint)
    result = classifier_predict(state["audio_path"], checkpoint_path=checkpoint)
    state["fake_probability"] = result.fake_probability
    state["model_name"] = result.model_name
    state["class_probs"] = result.class_probs
    state["predicted_class"] = result.predicted_class
    state["feature_attribution"] = result.feature_attribution
    state["feature_risks"] = result.feature_risks
    state["reasoning_trace"].append(
        f"Primary classifier ({result.model_name}) returned fake_probability="
        f"{result.fake_probability:.3f}, class_probs={result.class_probs}."
    )
    return state


def node_robustness_context(state: AgentState) -> AgentState:
    """Load Task 3 report and estimate how reliable the classifier is here."""
    cfg = state["config"]
    report_path = cfg["paths"].get("robustness_report")
    if report_path and not os.path.isabs(report_path):
        report_path = os.path.join(_PROJECT_ROOT, report_path)

    ctx = get_robustness_context(state["_features_obj"], report_path)
    state["robustness_context"] = {
        "report_available": ctx.report_available,
        "estimated_snr_db": round(ctx.estimated_snr_db, 1),
        "reliability_score": ctx.reliability_score,
        "expected_accuracy": ctx.expected_accuracy,
        "expected_f1": ctx.expected_f1,
        "degradation_risk": ctx.degradation_risk,
    }
    state["reasoning_trace"].append(f"Robustness context: {ctx.reason}")
    return state


def route_after_classification(state: AgentState) -> str:
    """THE AGENTIC DECISION POINT: trust the primary classifier, or gather more evidence?"""
    th = state["config"]["thresholds"]
    p = state["fake_probability"]
    if p >= th["high_confidence_fake"] or p <= th["high_confidence_real"]:
        state["ambiguous"] = False
        state["reasoning_trace"].append(
            "Score is outside the ambiguous range - proceeding directly to threat assessment."
        )
        return "confident"
    else:
        state["ambiguous"] = True
        state["reasoning_trace"].append(
            "Score falls in the ambiguous range - invoking secondary tools before deciding."
        )
        return "ambiguous"


def node_secondary_checks(state: AgentState) -> AgentState:
    noise_result = noise_robustness_check(state["_features_obj"])
    sig_path = state["config"]["paths"]["known_attack_signatures"]
    if not os.path.isabs(sig_path):
        sig_path = os.path.join(_PROJECT_ROOT, sig_path)
    sig_result = known_attack_signature_check(state["_features_obj"], sig_path)
    state["reliable_sample"] = noise_result["reliable_sample"]
    state["matched_attack_type"] = sig_result["matched_attack_type"]
    state["reasoning_trace"].append(f"Noise/robustness check: {noise_result['reason']}")
    state["reasoning_trace"].append(f"Attack signature check: {sig_result['reason']}")
    return state


def node_skip_secondary_checks(state: AgentState) -> AgentState:
    state["reliable_sample"] = True
    state["matched_attack_type"] = None
    return state


def node_threat_assessment(state: AgentState) -> AgentState:
    robustness_ctx = state.get("robustness_context") or {}
    result = assess(
        fake_probability=state["fake_probability"],
        matched_attack_type=state["matched_attack_type"],
        reliable_sample=state["reliable_sample"],
        is_ood=state["is_ood"],
        robustness_reliability=robustness_ctx.get("reliability_score", 1.0),
        degradation_risk=robustness_ctx.get("degradation_risk", "UNKNOWN"),
    )
    state["final_output"] = {
        "verdict": result.verdict,
        "risk_level": result.risk_level,
        "attack_type_guess": result.attack_type_guess,
        "confidence": result.confidence,
        "fake_probability": state["fake_probability"],
        "model_used": state["model_name"],
        "predicted_class": state["predicted_class"],
        "class_probs": state["class_probs"],
        "recommended_action": result.recommended_action,
        "robustness_context": state.get("robustness_context"),
        "feature_attribution": state.get("feature_attribution"),
        "feature_risks": state.get("feature_risks"),
        "ood": {
            "is_ood": state["is_ood"],
            "reason": state["ood_reason"],
        },
    }
    state["reasoning_trace"].append(
        f"Final verdict: {result.verdict} (risk={result.risk_level}, confidence={result.confidence})."
    )
    return state


def node_explain(state: AgentState) -> AgentState:
    llm_cfg = state["config"]["llm"]
    final = state["final_output"]
    prompt = (
        "You are a security analyst assistant. Given the evidence below from an "
        "automated voice anti-spoofing pipeline, write a short (3-5 sentence) "
        "human-readable explanation of the final verdict. Ground the explanation "
        "ONLY in the evidence given. Do not invent numbers.\n\n"
        "Key facts:\n"
        f"- Verdict: {final['verdict']}\n"
        f"- Risk level: {final['risk_level']}\n"
        f"- Confidence: {final['confidence']}\n"
        f"- Classifier fake probability: {state['fake_probability']:.3f}\n"
        f"- Classifier class probabilities: {final['class_probs']}\n"
        f"- Classifier predicted class: {final['predicted_class']}\n"
        f"- Classifier used: {final['model_used']}\n"
        f"- Out-of-distribution: {final['ood']['is_ood']}"
        f"{' (' + final['ood']['reason'] + ')' if final['ood']['is_ood'] else ''}\n"
        f"- Estimated effective SNR: {final['robustness_context']['estimated_snr_db']} dB\n"
        f"- Expected classifier accuracy in similar conditions: {final['robustness_context']['expected_accuracy']}\n"
        f"- Degradation risk: {final['robustness_context']['degradation_risk']}\n"
        f"- Recommended action: {final['recommended_action']}\n\n"
        "Full evidence trail:\n"
        + "\n".join(f"- {step}" for step in state["reasoning_trace"])
    )
    explanation = generate_reasoning(
        prompt,
        provider=llm_cfg["provider"],
        model=llm_cfg["model"],
        temperature=llm_cfg["temperature"],
        max_tokens=llm_cfg["max_tokens"],
    )
    state["final_output"]["explanation"] = explanation
    return state


# ------------------------------------------------------------------
# 3. Build the graph
# ------------------------------------------------------------------
def build_graph():
    graph = StateGraph(AgentState)

    graph.add_node("extract_features", node_extract_features)
    graph.add_node("ood_check", node_out_of_distribution_check)
    graph.add_node("classify", node_classify)
    graph.add_node("robustness_context", node_robustness_context)
    graph.add_node("secondary_checks", node_secondary_checks)
    graph.add_node("skip_secondary_checks", node_skip_secondary_checks)
    graph.add_node("threat_assessment", node_threat_assessment)
    graph.add_node("explain", node_explain)

    graph.set_entry_point("extract_features")
    graph.add_edge("extract_features", "ood_check")
    graph.add_edge("ood_check", "classify")
    graph.add_edge("classify", "robustness_context")

    graph.add_conditional_edges(
        "robustness_context",
        route_after_classification,
        {"ambiguous": "secondary_checks", "confident": "skip_secondary_checks"},
    )

    graph.add_edge("secondary_checks", "threat_assessment")
    graph.add_edge("skip_secondary_checks", "threat_assessment")
    graph.add_edge("threat_assessment", "explain")
    graph.add_edge("explain", END)

    return graph.compile()


# ------------------------------------------------------------------
# 4. Callable entry point (used by the CLI and by the Streamlit app)
# ------------------------------------------------------------------
def run(audio_path: str, config_path: Optional[str] = None) -> dict:
    if config_path is None:
        config_path = os.path.join(_PROJECT_ROOT, "config.yaml")
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    app = build_graph()
    initial_state: AgentState = {
        "audio_path": audio_path,
        "config": config,
        "features": None,
        "_features_obj": None,
        "fake_probability": None,
        "class_probs": None,
        "predicted_class": None,
        "model_name": None,
        "reliable_sample": None,
        "matched_attack_type": None,
        "is_ood": None,
        "ood_reason": None,
        "ambiguous": None,
        "robustness_context": None,
        "reasoning_trace": [],
        "final_output": None,
    }
    result_state = app.invoke(initial_state)

    output = result_state["final_output"]
    output["reasoning_trace"] = result_state["reasoning_trace"]
    output["features"] = result_state["features"]
    output["feature_attribution"] = result_state.get("feature_attribution")
    output["feature_risks"] = result_state.get("feature_risks")
    return output


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python src/task2_agent/graph.py <path_to_audio.wav>")
        sys.exit(1)

    output = run(sys.argv[1])
    print(json.dumps(output, indent=2))
