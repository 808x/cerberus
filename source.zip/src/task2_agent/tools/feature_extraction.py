"""
tools/feature_extraction.py

Pure signal-processing tool used by the agent. No model inference happens
here - only raw acoustic feature extraction that both the classifier (Task 1)
and the explainability module (this task) can consume.

Swap-in point: if your Task 1 model expects a different feature set
(e.g. raw waveform for an end-to-end model, or log-mel spectrograms),
adjust `extract_features` accordingly - just keep the returned dict shape
consistent so downstream tools don't break.
"""

from dataclasses import dataclass, asdict
import numpy as np
import librosa


@dataclass
class AudioFeatures:
    duration_sec: float
    mfcc_mean: list
    mfcc_std: list
    pitch_mean: float
    pitch_jitter: float          # frame-to-frame pitch variability
    spectral_flatness_mean: float
    spectral_centroid_mean: float
    silence_ratio: float         # proportion of frame classified as silence
    high_freq_energy_ratio: float  # proxy for vocoder/TTS artifacts

    def to_dict(self):
        return asdict(self)


def extract_features(audio_path: str, sample_rate: int = 16000, n_mfcc: int = 40) -> AudioFeatures:
    """Load an audio file and extract a compact, model-and-human-readable feature set."""
    y, sr = librosa.load(audio_path, sr=sample_rate, mono=True)

    duration_sec = float(len(y) / sr)

    # MFCCs - timbral fingerprint
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
    mfcc_mean = mfcc.mean(axis=1).tolist()
    mfcc_std = mfcc.std(axis=1).tolist()

    # Pitch (f0) tracking via pyin - robust for voiced speech
    f0, voiced_flag, _ = librosa.pyin(
        y, fmin=librosa.note_to_hz("C2"), fmax=librosa.note_to_hz("C7"), sr=sr
    )
    f0_voiced = f0[voiced_flag] if voiced_flag is not None else np.array([])
    pitch_mean = float(np.nanmean(f0_voiced)) if f0_voiced.size > 0 else 0.0
    pitch_jitter = float(np.nanstd(np.diff(f0_voiced))) if f0_voiced.size > 1 else 0.0

    # Spectral flatness - synthetic/vocoded audio tends to be flatter (less natural noise)
    spectral_flatness_mean = float(librosa.feature.spectral_flatness(y=y).mean())

    # Spectral centroid - brightness of the sound
    spectral_centroid_mean = float(librosa.feature.spectral_centroid(y=y, sr=sr).mean())

    # Silence ratio - via RMS energy thresholding
    rms = librosa.feature.rms(y=y)[0]
    silence_ratio = float(np.mean(rms < (0.02 * rms.max()))) if rms.max() > 0 else 1.0

    # High-frequency energy ratio - many TTS/vocoder artifacts show up as
    # unnatural energy above ~4kHz relative to total energy
    stft = np.abs(librosa.stft(y))
    freqs = librosa.fft_frequencies(sr=sr)
    hf_mask = freqs >= 4000
    total_energy = stft.sum() + 1e-8
    hf_energy = stft[hf_mask, :].sum()
    high_freq_energy_ratio = float(hf_energy / total_energy)

    return AudioFeatures(
        duration_sec=duration_sec,
        mfcc_mean=mfcc_mean,
        mfcc_std=mfcc_std,
        pitch_mean=pitch_mean,
        pitch_jitter=pitch_jitter,
        spectral_flatness_mean=spectral_flatness_mean,
        spectral_centroid_mean=spectral_centroid_mean,
        silence_ratio=silence_ratio,
        high_freq_energy_ratio=high_freq_energy_ratio,
    )
