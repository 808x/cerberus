"""
src/api/main.py

FastAPI backend for the Cerberus dashboard.

Endpoints:
    POST /analyze                 — upload a .wav file, run full agentic pipeline
    POST /analyze/sample        — analyze a bundled sample by name
    POST /analyze/chunk         — analyze a short audio chunk (for live mic/streaming)
    GET  /health                — service health + model availability
    GET  /samples               — list bundled demo samples
    GET  /samples/{name}        — serve a bundled sample

Task execution (pipeline buttons):
    POST /tasks/build_dataset   — run Task 0 dataset builder
    POST /tasks/train           — run Task 1 training
    POST /tasks/evaluate        — run Task 1 evaluation
    POST /tasks/robustness      — run Task 3 robustness evaluation
    GET  /tasks/{job_id}        — get job status + output

WebSocket:
    /ws/{job_id}                — stream job output lines in real time
"""

import asyncio
import glob
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import uuid
from contextlib import asynccontextmanager
from typing import Dict, Optional

import librosa
import numpy as np
import soundfile as sf
from fastapi import (
    BackgroundTasks,
    FastAPI,
    File,
    HTTPException,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))
sys.path.append(os.path.join(_PROJECT_ROOT, "src", "task2_agent"))
sys.path.append(_PROJECT_ROOT)

import graph as agent_graph

SAMPLE_DIR = os.path.join(_PROJECT_ROOT, "samples")
CHECKPOINT_PATH = os.path.join(_PROJECT_ROOT, "models", "task1_classifier.pt")

# In-memory job store. For multi-process deployments this would be Redis.
JOBS: Dict[str, dict] = {}


class AnalyzeSampleRequest(BaseModel):
    sample_name: str


class HealthResponse(BaseModel):
    status: str
    checkpoint_available: bool
    sample_count: int


class TaskStatusResponse(BaseModel):
    job_id: str
    task: str
    status: str  # queued | running | completed | failed
    output: list
    returncode: Optional[int]


@asynccontextmanager
async def lifespan(app: FastAPI):
    os.makedirs(SAMPLE_DIR, exist_ok=True)
    yield


app = FastAPI(
    title="Cerberus Voice Spoofing Detector API",
    description="Agentic AI pipeline for detecting AI-generated/cloned speech.",
    version="2.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

STATIC_DIR = os.path.join(_THIS_DIR, "static")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _ensure_wav(input_path: str, output_path: str) -> None:
    """Load audio with librosa and write a clean mono WAV at 16 kHz."""
    y, sr = librosa.load(input_path, sr=16000, mono=True)
    if y.size == 0:
        raise ValueError("Audio file is empty")
    peak = np.max(np.abs(y))
    if peak > 0:
        y = y / peak
    sf.write(output_path, y, 16000)


def _run_pipeline(audio_path: str) -> dict:
    try:
        result = agent_graph.run(audio_path)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Pipeline failed: {exc}")
    return result


def _run_script(job_id: str, task: str, cmd: list):
    """Run a shell command, capture output, and update the job store."""
    JOBS[job_id]["status"] = "running"
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            cwd=_PROJECT_ROOT,
            bufsize=1,
        )
        JOBS[job_id]["pid"] = proc.pid
        for line in proc.stdout:
            JOBS[job_id]["output"].append(line.rstrip("\n"))
            # keep last 2000 lines
            if len(JOBS[job_id]["output"]) > 2000:
                JOBS[job_id]["output"].pop(0)
        proc.wait()
        JOBS[job_id]["returncode"] = proc.returncode
        JOBS[job_id]["status"] = "completed" if proc.returncode == 0 else "failed"
    except Exception as exc:
        JOBS[job_id]["output"].append(f"[error] {exc}")
        JOBS[job_id]["status"] = "failed"


def _start_job(task: str, cmd: list) -> str:
    job_id = str(uuid.uuid4())
    JOBS[job_id] = {
        "job_id": job_id,
        "task": task,
        "status": "queued",
        "output": [],
        "returncode": None,
        "pid": None,
    }
    thread = threading.Thread(target=_run_script, args=(job_id, task, cmd), daemon=True)
    thread.start()
    return job_id


# ------------------------------------------------------------------
# Static UI
# ------------------------------------------------------------------
@app.get("/")
def root():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


@app.get("/health", response_model=HealthResponse)
def health():
    samples = sorted(glob.glob(os.path.join(SAMPLE_DIR, "*.wav")))
    return {
        "status": "ok",
        "checkpoint_available": os.path.exists(CHECKPOINT_PATH),
        "sample_count": len(samples),
    }


@app.get("/samples")
def list_samples():
    samples = sorted(glob.glob(os.path.join(SAMPLE_DIR, "*.wav")))
    return {"samples": [os.path.basename(s) for s in samples]}


@app.get("/samples/{sample_name}")
def serve_sample(sample_name: str):
    audio_path = os.path.join(SAMPLE_DIR, sample_name)
    if not os.path.exists(audio_path):
        raise HTTPException(
            status_code=404, detail=f"Sample '{sample_name}' not found."
        )
    return FileResponse(audio_path, media_type="audio/wav")


# ------------------------------------------------------------------
# Analysis endpoints
# ------------------------------------------------------------------
@app.post("/analyze")
def analyze(file: UploadFile = File(...)):
    suffix = os.path.splitext(file.filename)[1] or ".wav"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(file.file.read())
        tmp_path = tmp.name

    wav_path = tmp_path
    if suffix.lower() != ".wav":
        wav_path = tmp_path + ".wav"
        try:
            _ensure_wav(tmp_path, wav_path)
        except Exception as exc:
            os.remove(tmp_path)
            raise HTTPException(
                status_code=400, detail=f"Audio conversion failed: {exc}"
            )

    try:
        result = _run_pipeline(wav_path)
    finally:
        for p in (tmp_path, wav_path):
            try:
                if p and os.path.exists(p):
                    os.remove(p)
            except OSError:
                pass

    return JSONResponse(content=result)


@app.post("/analyze/sample")
def analyze_sample(req: AnalyzeSampleRequest):
    audio_path = os.path.join(SAMPLE_DIR, req.sample_name)
    if not os.path.exists(audio_path):
        raise HTTPException(
            status_code=404, detail=f"Sample '{req.sample_name}' not found."
        )
    result = _run_pipeline(audio_path)
    return JSONResponse(content=result)


@app.post("/analyze/chunk")
def analyze_chunk(file: UploadFile = File(...)):
    """Analyze a short audio chunk (for live mic / streaming)."""
    suffix = os.path.splitext(file.filename)[1] or ".wav"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(file.file.read())
        tmp_path = tmp.name

    wav_path = tmp_path
    if suffix.lower() != ".wav":
        wav_path = tmp_path + ".wav"

    try:
        _ensure_wav(tmp_path, wav_path)
    except Exception as exc:
        for p in (tmp_path, wav_path):
            try:
                if p and os.path.exists(p):
                    os.remove(p)
            except OSError:
                pass
        raise HTTPException(status_code=400, detail=f"Audio conversion failed: {exc}")

    try:
        result = _run_pipeline(wav_path)
        # Slim response for streaming
        slim = {
            "fake_probability": result.get("fake_probability"),
            "class_probs": result.get("class_probs"),
            "predicted_class": result.get("predicted_class"),
            "verdict": result.get("verdict"),
            "risk_level": result.get("risk_level"),
            "confidence": result.get("confidence"),
            "features": result.get("features"),
            "feature_risks": result.get("feature_risks"),
            "robustness_context": result.get("robustness_context"),
        }
    finally:
        for p in (tmp_path, wav_path):
            try:
                if p and os.path.exists(p):
                    os.remove(p)
            except OSError:
                pass

    return JSONResponse(content=slim)


# ------------------------------------------------------------------
# Task execution endpoints
# ------------------------------------------------------------------
@app.post("/tasks/build_dataset")
def task_build_dataset(background_tasks: BackgroundTasks):
    cmd = [
        sys.executable,
        "src/task0_cloning/build_adversarial_dataset.py",
        "--clear",
        "--n-distort-per-real",
        "2",
    ]
    job_id = _start_job("build_dataset", cmd)
    return {"job_id": job_id, "status": "queued"}


@app.post("/tasks/train")
def task_train(background_tasks: BackgroundTasks):
    cmd = [
        sys.executable,
        "src/task1_classifier/train.py",
        "--epochs",
        "30",
        "--data-root",
        "data",
    ]
    job_id = _start_job("train", cmd)
    return {"job_id": job_id, "status": "queued"}


@app.post("/tasks/evaluate")
def task_evaluate(background_tasks: BackgroundTasks):
    cmd = [
        sys.executable,
        "src/task1_classifier/evaluate.py",
        "--data-root",
        "data",
        "--out-dir",
        "reports",
    ]
    job_id = _start_job("evaluate", cmd)
    return {"job_id": job_id, "status": "queued"}


@app.post("/tasks/robustness")
def task_robustness(background_tasks: BackgroundTasks):
    cmd = [
        sys.executable,
        "src/task3_robustness/robustness_eval.py",
        "--data-root",
        "data",
        "--checkpoint",
        "models/task1_classifier.pt",
        "--out",
        "reports/task3_robustness.json",
        "--tmp-dir",
        "/DATA/Cerberus/_tmp_perturbed",
        "--n-jobs",
        "32",
    ]
    job_id = _start_job("robustness", cmd)
    return {"job_id": job_id, "status": "queued"}


@app.get("/tasks/{job_id}")
def task_status(job_id: str):
    if job_id not in JOBS:
        raise HTTPException(status_code=404, detail="Job not found")
    return JOBS[job_id]


# ------------------------------------------------------------------
# WebSocket for streaming job output
# ------------------------------------------------------------------
@app.websocket("/ws/{job_id}")
async def websocket_job(websocket: WebSocket, job_id: str):
    await websocket.accept()
    if job_id not in JOBS:
        await websocket.send_text(json.dumps({"error": "Job not found"}))
        await websocket.close()
        return

    last_len = 0
    try:
        while True:
            job = JOBS[job_id]
            output = job["output"]
            if len(output) > last_len:
                new_lines = output[last_len:]
                last_len = len(output)
                await websocket.send_text(
                    json.dumps(
                        {
                            "status": job["status"],
                            "lines": new_lines,
                            "returncode": job["returncode"],
                        }
                    )
                )
            elif job["status"] in ("completed", "failed"):
                await websocket.send_text(
                    json.dumps(
                        {
                            "status": job["status"],
                            "lines": [],
                            "returncode": job["returncode"],
                        }
                    )
                )
                await websocket.close()
                return
            await asyncio.sleep(0.5)
    except WebSocketDisconnect:
        pass
    except Exception as exc:
        await websocket.send_text(json.dumps({"error": str(exc)}))
        await websocket.close()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
