"""
src/task0_cloning/download_external_data.py

Downloads public external datasets to reduce overfitting:
  - LibriSpeech dev-clean (real speech, diverse speakers)
  - WaveFake (TTS-generated fake speech)

Output:
  /DATA/Cerberus/external_data/librispeech/dev-clean/*.wav
  /DATA/Cerberus/external_data/wavefake/*.wav

Usage:
    python src/task0_cloning/download_external_data.py
"""

import argparse
import os
import shutil
import subprocess
import sys
import tarfile
import urllib.request
from pathlib import Path

import librosa
import soundfile as sf
from tqdm import tqdm

EXTERNAL_ROOT = Path("/DATA/Cerberus/external_data")
LIBRISPEECH_URL = "https://www.openslr.org/resources/12/dev-clean.tar.gz"
LIBRISPEECH_TAR = EXTERNAL_ROOT / "dev-clean.tar.gz"
LIBRISPEECH_DIR = EXTERNAL_ROOT / "librispeech" / "dev-clean"

WAVEFAKE_HF_REPO = "Francissssss/wavefake"
WAVEFAKE_DIR = EXTERNAL_ROOT / "wavefake"


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument(
        "--skip-librispeech", action="store_true", help="Skip LibriSpeech download"
    )
    p.add_argument(
        "--skip-wavefake", action="store_true", help="Skip WaveFake download"
    )
    p.add_argument(
        "--wavefake-max-gb",
        type=float,
        default=2.0,
        help="Maximum WaveFake size to download in GB",
    )
    return p.parse_args()


class TqdmUpTo(tqdm):
    """urllib download progress bar."""

    def update_to(self, b=1, bsize=1, tsize=None):
        if tsize is not None:
            self.total = tsize
        self.update(b * bsize - self.n)


def download_file(url: str, out_path: Path):
    print(f"Downloading {url} ...")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with TqdmUpTo(unit="B", unit_scale=True, unit_divisor=1024, miniters=1) as t:
        urllib.request.urlretrieve(
            url, filename=str(out_path), reporthook=t.update_to, data=None
        )
    print(f"Saved to {out_path}")


def extract_librispeech():
    print("Extracting LibriSpeech...")
    extract_to = EXTERNAL_ROOT / "librispeech_raw"
    if extract_to.exists():
        shutil.rmtree(extract_to)
    with tarfile.open(LIBRISPEECH_TAR, "r:gz") as tar:
        tar.extractall(path=str(extract_to))

    raw_dir = extract_to / "LibriSpeech" / "dev-clean"
    if not raw_dir.exists():
        raise RuntimeError(f"Expected {raw_dir} after extraction")

    print("Converting LibriSpeech to 16 kHz mono WAV...")
    flac_files = sorted(raw_dir.rglob("*.flac"))
    LIBRISPEECH_DIR.mkdir(parents=True, exist_ok=True)
    for i, flac_path in enumerate(tqdm(flac_files, desc="Converting")):
        y, sr = librosa.load(str(flac_path), sr=16000, mono=True)
        out_path = LIBRISPEECH_DIR / f"librispeech_{i:05d}.wav"
        sf.write(out_path, y, 16000)

    shutil.rmtree(extract_to)
    LIBRISPEECH_TAR.unlink(missing_ok=True)
    print(f"LibriSpeech ready: {len(list(LIBRISPEECH_DIR.glob('*.wav')))} files")


def download_wavefake(max_gb: float):
    """Download WaveFake via huggingface-cli if available."""
    try:
        import huggingface_hub
    except ImportError:
        print("huggingface_hub not installed. Installing...")
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "huggingface_hub"]
        )
        import huggingface_hub

    print(f"Downloading WaveFake (up to {max_gb} GB)...")
    WAVEFAKE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        huggingface_hub.snapshot_download(
            repo_id=WAVEFAKE_HF_REPO,
            repo_type="dataset",
            local_dir=str(WAVEFAKE_DIR),
            local_dir_use_symlinks=False,
            max_workers=4,
        )
        print(f"WaveFake saved to {WAVEFAKE_DIR}")
    except Exception as e:
        print(f"WaveFake download failed: {e}")
        print(
            "Continuing without WaveFake; you can still use LibriSpeech for real diversity."
        )


def main():
    args = parse_args()
    EXTERNAL_ROOT.mkdir(parents=True, exist_ok=True)

    if not args.skip_librispeech:
        if not LIBRISPEECH_DIR.exists() or not any(LIBRISPEECH_DIR.glob("*.wav")):
            download_file(LIBRISPEECH_URL, LIBRISPEECH_TAR)
            extract_librispeech()
        else:
            print(f"LibriSpeech already exists at {LIBRISPEECH_DIR}")

    if not args.skip_wavefake:
        download_wavefake(args.wavefake_max_gb)

    print("\nExternal data download complete.")
    print(f"  LibriSpeech: {LIBRISPEECH_DIR}")
    print(f"  WaveFake:    {WAVEFAKE_DIR}")


if __name__ == "__main__":
    main()
