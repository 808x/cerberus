"""
src/task1_classifier/feature_extraction.py

Rich adversarial-aware feature extractor for Task 1.
"""

from typing import Dict, List

import librosa
import numpy as np
from scipy.signal import lfilter

TARGET_SR = 16000
N_MFCC = 40
N_LFCC = 13


def _safe_mean(a: np.ndarray) -> float:
    return float(np.nanmean(a)) if a is not None and a.size > 0 else 0.0


def _safe_std(a: np.ndarray) -> float:
    return float(np.nanstd(a)) if a is not None and a.size > 0 else 0.0


def _compute_hnr(y: np.ndarray) -> float:
    y = y - np.mean(y)
    corr = np.correlate(y, y, mode="full")
    corr = corr[len(corr) // 2 :]
    if len(corr) < 2 or corr[0] <= 0:
        return 0.0
    peak = np.max(corr[1:])
    noise = corr[0] - peak
    if noise <= 0:
        return 60.0
    hnr_db = 10.0 * np.log10(peak / noise)
    return float(np.clip(hnr_db, -20, 60))


def _compute_pitch_quantization_score(f0: np.ndarray) -> float:
    voiced = f0[~np.isnan(f0) & (f0 > 0)]
    if len(voiced) < 5:
        return 0.0
    midi = 69 + 12 * np.log2(voiced / 440.0)
    deviation = np.abs(midi - np.round(midi))
    on_grid = np.mean(deviation < 0.05)
    return float(on_grid)


def _compute_formants(y: np.ndarray, sr: int, n_formants: int = 3) -> Dict[str, float]:
    try:
        y = lfilter([1.0, -0.97], [1.0], y)
        order = int(2 + sr / 1000)
        lpc_coeffs = librosa.lpc(y, order=order)
        roots = np.roots(lpc_coeffs)
        roots = roots[np.imag(roots) >= 0]
        angles = np.arctan2(np.imag(roots), np.real(roots))
        freqs = angles * (sr / (2 * np.pi))
        bandwidths = (
            -0.5 * (sr / (2 * np.pi)) * np.log(np.maximum(np.abs(roots), 1e-12))
        )
        valid = (freqs > 90) & (freqs < 4000) & (bandwidths > 0)
        freqs = freqs[valid]
        bandwidths = bandwidths[valid]
        idx = np.argsort(freqs)
        freqs = freqs[idx]
        bandwidths = bandwidths[idx]
    except Exception:
        freqs, bandwidths = np.array([]), np.array([])

    out = {}
    for i in range(n_formants):
        out[f"formant_{i + 1}_freq"] = float(freqs[i]) if i < len(freqs) else 0.0
        out[f"formant_{i + 1}_bw"] = (
            float(bandwidths[i]) if i < len(bandwidths) else 0.0
        )
    return out


def extract_features(audio_path: str, sample_rate: int = TARGET_SR) -> Dict[str, float]:
    y, sr = librosa.load(audio_path, sr=sample_rate, mono=True)
    peak = np.max(np.abs(y))
    if peak > 0:
        y = y / peak

    features: Dict[str, float] = {}
    features["duration_sec"] = float(len(y) / sr)

    # Compute once and reuse
    f0, voiced_flag, _ = librosa.pyin(
        y, fmin=librosa.note_to_hz("C2"), fmax=librosa.note_to_hz("C7"), sr=sr
    )
    f0_voiced = f0[voiced_flag] if voiced_flag is not None else np.array([])
    f0_voiced = f0_voiced[~np.isnan(f0_voiced)]

    spec = np.abs(librosa.stft(y))
    freqs = librosa.fft_frequencies(sr=sr)
    total_energy = spec.sum() + 1e-8

    # MFCC
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=N_MFCC)
    for i in range(N_MFCC):
        features[f"mfcc_{i}_mean"] = _safe_mean(mfcc[i])
        features[f"mfcc_{i}_std"] = _safe_std(mfcc[i])

    mfcc_delta = librosa.feature.delta(mfcc)
    mfcc_delta2 = librosa.feature.delta(mfcc, order=2)
    for i in range(N_MFCC):
        features[f"mfcc_delta_{i}_mean"] = _safe_mean(mfcc_delta[i])
        features[f"mfcc_delta2_{i}_mean"] = _safe_mean(mfcc_delta2[i])

    # LFCC
    lfcc = librosa.feature.mfcc(
        S=librosa.power_to_db(spec), sr=sr, n_mfcc=N_LFCC, n_mels=N_LFCC * 2
    )
    for i in range(N_LFCC):
        features[f"lfcc_{i}_mean"] = _safe_mean(lfcc[i])
        features[f"lfcc_{i}_std"] = _safe_std(lfcc[i])

    # Pitch
    features["pitch_mean"] = _safe_mean(f0_voiced)
    features["pitch_std"] = _safe_std(f0_voiced)
    features["pitch_range"] = (
        float(np.max(f0_voiced) - np.min(f0_voiced)) if f0_voiced.size > 1 else 0.0
    )
    features["pitch_jitter"] = (
        _safe_std(np.diff(f0_voiced)) if f0_voiced.size > 1 else 0.0
    )
    features["voiced_frames_ratio"] = (
        float(np.mean(voiced_flag)) if voiced_flag is not None else 0.0
    )
    features["pitch_quantization_score"] = _compute_pitch_quantization_score(f0)

    # Energy / temporal
    rms = librosa.feature.rms(y=y)[0]
    zcr = librosa.feature.zero_crossing_rate(y)[0]
    features["rms_mean"] = _safe_mean(rms)
    features["rms_std"] = _safe_std(rms)
    features["dynamic_range"] = (
        float(np.max(rms) - np.min(rms)) if rms.size > 0 else 0.0
    )
    features["zero_crossing_rate_mean"] = _safe_mean(zcr)
    features["zero_crossing_rate_std"] = _safe_std(zcr)
    features["silence_ratio"] = (
        float(np.mean(rms < (0.02 * rms.max()))) if rms.max() > 0 else 1.0
    )
    features["shimmer_proxy"] = _safe_std(np.diff(rms)) if rms.size > 1 else 0.0

    # Spectral
    features["spectral_flatness_mean"] = _safe_mean(
        librosa.feature.spectral_flatness(y=y)[0]
    )
    features["spectral_centroid_mean"] = _safe_mean(
        librosa.feature.spectral_centroid(y=y, sr=sr)[0]
    )
    features["spectral_rolloff_mean"] = _safe_mean(
        librosa.feature.spectral_rolloff(y=y, sr=sr)[0]
    )
    features["spectral_bandwidth_mean"] = _safe_mean(
        librosa.feature.spectral_bandwidth(y=y, sr=sr)[0]
    )

    contrast = librosa.feature.spectral_contrast(y=y, sr=sr)
    for i in range(contrast.shape[0]):
        features[f"spectral_contrast_{i}_mean"] = _safe_mean(contrast[i])

    flux = librosa.onset.onset_strength(y=y, sr=sr)
    features["spectral_flux_mean"] = _safe_mean(flux)
    features["spectral_flux_std"] = _safe_std(flux)

    features["high_freq_energy_ratio"] = float(
        spec[freqs >= 4000, :].sum() / total_energy
    )
    features["mid_freq_energy_ratio"] = float(
        spec[(freqs >= 1000) & (freqs < 4000), :].sum() / total_energy
    )

    # Harmonicity
    features["hnr_db"] = _compute_hnr(y)
    y_harmonic, _ = librosa.effects.hpss(y)
    features["tonal_ratio"] = float(np.sum(y_harmonic**2) / (np.sum(y**2) + 1e-8))

    y_centered = y - np.mean(y)
    autocorr = np.correlate(y_centered, y_centered, mode="full")
    autocorr = autocorr[len(autocorr) // 2 :]
    features["autocorrelation_peak"] = (
        float(np.max(autocorr[1:]) / (autocorr[0] + 1e-8)) if len(autocorr) > 1 else 0.0
    )

    # Formants
    features.update(_compute_formants(y, sr))

    return features


def feature_vector(features: Dict[str, float]) -> np.ndarray:
    return np.array(list(features.values()), dtype=np.float32)


def feature_names() -> List[str]:
    import tempfile

    import soundfile as sf

    y = np.zeros(TARGET_SR, dtype=np.float32)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        sf.write(f.name, y, TARGET_SR)
        feats = extract_features(f.name)
    return list(feats.keys())
