"""
src/task0_cloning/generate_dataset.py

Builds the paired real/synthetic dataset that Task 1 trains on, using the
same pipeline already prototyped in VOICE_CLONER/Cloner.ipynb + tts.ipynb:
  - Real speech: CMU ARCTIC (torchaudio built-in dataset, auto-downloads)
  - Synthetic speech: Coqui XTTS v2, cloning each speaker's own voice
    (so the classifier learns "real vs. AI-cloned", not "speaker A vs B")

Two modes:
  --mode xtts   (default) Full quality clones via Coqui TTS XTTS v2.
                Requires: pip install TTS, a GPU is strongly recommended,
                first run downloads ~2GB of model weights.
  --mode quick  No TTS model download needed. Produces "fake" samples via
                signal-level manipulation (pitch/formant shifting + vocoder-
                like spectral flattening) that mimics common synthetic-speech
                artifacts. Use this to get an end-to-end pipeline running in
                minutes for a hackathon demo, then swap to --mode xtts for
                the real submission if time allows.

Usage:
    python src/task0_cloning/generate_dataset.py --mode quick --n-speakers 4 --n-per-speaker 25
    python src/task0_cloning/generate_dataset.py --mode xtts  --n-speakers 4 --n-per-speaker 15

Output:
    data/real/*.wav
    data/fake/*.wav
"""

import os
import argparse
import numpy as np
import torch
import torchaudio
import torchaudio.transforms as T

TARGET_SR = 16000


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["xtts", "quick"], default="quick")
    p.add_argument("--speakers", nargs="+", default=["aew", "clb", "bdl", "slt"],
                    help="CMU ARCTIC speaker codes to use")
    p.add_argument("--n-per-speaker", type=int, default=20,
                    help="How many real utterances per speaker to use/clone")
    p.add_argument("--real-out", default="data/real")
    p.add_argument("--fake-out", default="data/fake")
    p.add_argument("--data-root", default="./data/_cmu_arctic_raw")
    return p.parse_args()


def _load_and_preprocess(waveform, sr):
    if waveform.shape[0] > 1:
        waveform = torch.mean(waveform, dim=0, keepdim=True)
    if sr != TARGET_SR:
        waveform = T.Resample(orig_freq=sr, new_freq=TARGET_SR)(waveform)
    peak = waveform.abs().max()
    if peak > 0:
        waveform = waveform / peak
    return waveform


def _quick_fake(waveform: torch.Tensor) -> torch.Tensor:
    """
    Signal-level stand-in for a TTS/vocoder artifact profile — NOT a real
    voice clone, but fast and dependency-free. Mimics two things real
    neural vocoders commonly introduce: (1) reduced pitch micro-variation
    (unnaturally smooth F0) and (2) flattened/boosted high-frequency
    spectral content. Good enough to bootstrap Task 1 training and to
    smoke-test the whole pipeline before XTTS is wired in.
    """
    import librosa
    y = waveform.squeeze(0).numpy()

    # Slight pitch shift (formant-preserving) — simulates voice conversion
    y_shifted = librosa.effects.pitch_shift(y, sr=TARGET_SR, n_steps=np.random.uniform(-1.5, 1.5))

    # Spectral flattening via light Wiener-like smoothing — simulates vocoder smoothing
    stft = librosa.stft(y_shifted)
    mag, phase = np.abs(stft), np.angle(stft)
    mag_smooth = np.clip(mag * 0.85 + np.mean(mag, axis=0, keepdims=True) * 0.15, 0, None)
    y_out = librosa.istft(mag_smooth * np.exp(1j * phase), length=len(y))

    y_out = y_out / (np.max(np.abs(y_out)) + 1e-8)
    return torch.tensor(y_out, dtype=torch.float32).unsqueeze(0)


def run_quick(args):
    os.makedirs(args.real_out, exist_ok=True)
    os.makedirs(args.fake_out, exist_ok=True)

    for code in args.speakers:
        print(f"Downloading/loading CMU ARCTIC speaker: {code}")
        ds = torchaudio.datasets.CMUARCTIC(root=args.data_root, url=code, download=True)
        n = min(args.n_per_speaker, len(ds))
        for i in range(n):
            waveform, sr, _, _ = ds[i]
            wf = _load_and_preprocess(waveform, sr)

            real_path = os.path.join(args.real_out, f"{code}_{i:03d}_real.wav")
            torchaudio.save(real_path, wf, TARGET_SR)

            fake_wf = _quick_fake(wf)
            fake_path = os.path.join(args.fake_out, f"{code}_{i:03d}_fake_quick.wav")
            torchaudio.save(fake_path, fake_wf, TARGET_SR)

        print(f"  -> {n} real + {n} fake samples written for speaker {code}")

    print("\nQuick-mode dataset generation complete.")


def run_xtts(args):
    from TTS.api import TTS

    os.makedirs(args.real_out, exist_ok=True)
    os.makedirs(args.fake_out, exist_ok=True)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Loading XTTS v2 on {device} (first run downloads ~2GB)...")
    tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(device)

    sample_texts = [
        "The quick brown fox jumps over the lazy dog near the riverbank.",
        "Artificial intelligence is changing how we communicate every day.",
        "Please confirm your identity before we proceed with this transaction.",
        "The weather today is expected to be clear with a gentle breeze.",
        "Security systems must adapt quickly to new kinds of digital threats.",
    ]

    for code in args.speakers:
        print(f"Downloading/loading CMU ARCTIC speaker: {code}")
        ds = torchaudio.datasets.CMUARCTIC(root=args.data_root, url=code, download=True)
        n = min(args.n_per_speaker, len(ds))

        # Use the speaker's first clip as the cloning reference voice
        ref_waveform, ref_sr, _, _ = ds[0]
        ref_wf = _load_and_preprocess(ref_waveform, ref_sr)
        ref_path = os.path.join(args.real_out, f"_{code}_reference.wav")
        torchaudio.save(ref_path, ref_wf, TARGET_SR)

        for i in range(n):
            waveform, sr, utterance, _ = ds[i]
            wf = _load_and_preprocess(waveform, sr)
            real_path = os.path.join(args.real_out, f"{code}_{i:03d}_real.wav")
            torchaudio.save(real_path, wf, TARGET_SR)

            text = utterance if utterance else sample_texts[i % len(sample_texts)]
            fake_path = os.path.join(args.fake_out, f"{code}_{i:03d}_fake_xtts.wav")
            tts.tts_to_file(text=text, speaker_wav=ref_path, language="en", file_path=fake_path)

        print(f"  -> {n} real + {n} XTTS-cloned fake samples written for speaker {code}")

    print("\nXTTS-mode dataset generation complete.")


def main():
    args = parse_args()
    if args.mode == "quick":
        run_quick(args)
    else:
        run_xtts(args)


if __name__ == "__main__":
    main()
