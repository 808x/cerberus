"""
src/task1_classifier/evaluate.py

3-class evaluation of the trained Task 1 checkpoint.

Produces:
  - overall accuracy, weighted F1
  - per-class precision/recall/F1
  - confusion matrix plot
  - JSON metrics file

Usage:
    python src/task1_classifier/evaluate.py \
        --data-root data \
        --checkpoint models/task1_classifier.pt \
        --out-dir reports
"""

import argparse
import json
import os
import sys

import matplotlib
import numpy as np
import torch

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    precision_recall_fscore_support,
)

sys.path.append(os.path.dirname(__file__))
from dataset import apply_scaler, build_raw_dataset
from model import build_model

CLASS_NAMES = ["real", "fake_synth", "fake_distort"]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", default="data")
    p.add_argument("--checkpoint", default="models/task1_classifier.pt")
    p.add_argument("--out-dir", default="reports")
    p.add_argument("--n-jobs", type=int, default=-1)
    return p.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    ckpt = torch.load(args.checkpoint, map_location="cpu")
    model = build_model(
        in_dim=ckpt["in_dim"],
        hidden=ckpt["hidden"],
        dropout=ckpt.get("dropout", 0.4),
        n_classes=ckpt.get("n_classes", 3),
    )
    model.load_state_dict(ckpt["state_dict"])
    model.eval()

    print(f"Loading data from {args.data_root} ...")
    X, y, paths = build_raw_dataset(args.data_root, n_jobs=args.n_jobs)
    X = apply_scaler(X, ckpt["scaler"])

    with torch.no_grad():
        logits = model(torch.tensor(X, dtype=torch.float32))
        probs = torch.softmax(logits, dim=1).numpy()
    preds = probs.argmax(axis=1)

    acc = accuracy_score(y, preds)
    precision, recall, f1, _ = precision_recall_fscore_support(
        y, preds, average="weighted", zero_division=0
    )
    per_class_p, per_class_r, per_class_f1, _ = precision_recall_fscore_support(
        y, preds, labels=[0, 1, 2], zero_division=0
    )

    metrics = {
        "n_samples": len(y),
        "accuracy": round(float(acc), 4),
        "weighted_f1": round(float(f1), 4),
        "per_class": {},
    }
    for i, name in enumerate(CLASS_NAMES):
        metrics["per_class"][name] = {
            "precision": round(float(per_class_p[i]), 4),
            "recall": round(float(per_class_r[i]), 4),
            "f1": round(float(per_class_f1[i]), 4),
            "support": int((y == i).sum()),
        }

    print(json.dumps(metrics, indent=2))
    with open(os.path.join(args.out_dir, "task1_eval_metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    # Confusion matrix
    cm = confusion_matrix(y, preds, labels=[0, 1, 2])
    plt.figure(figsize=(6, 5))
    plt.imshow(cm, cmap="Blues")
    plt.title("Task 1 Classifier — Confusion Matrix")
    plt.colorbar()
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            plt.text(j, i, str(cm[i, j]), ha="center", va="center")
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.xticks([0, 1, 2], CLASS_NAMES, rotation=45)
    plt.yticks([0, 1, 2], CLASS_NAMES)
    plt.tight_layout()
    plt.savefig(os.path.join(args.out_dir, "confusion_matrix.png"), dpi=150)
    plt.close()

    print(f"\nConfusion matrix saved to {args.out_dir}/confusion_matrix.png")


if __name__ == "__main__":
    main()
