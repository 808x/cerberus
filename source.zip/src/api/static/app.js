const API_URL = window.location.origin;

const els = {
    status: document.getElementById("api-status"),
    errorToast: document.getElementById("error-toast"),
    dropzone: document.getElementById("dropzone"),
    input: document.getElementById("audio-input"),
    browseBtn: document.getElementById("browse-btn"),
    sampleSelect: document.getElementById("sample-select"),
    analyzeBtn: document.getElementById("analyze-btn"),
    preview: document.getElementById("preview"),

    // Tabs
    tabBtns: document.querySelectorAll(".tab-btn"),
    tabContents: document.querySelectorAll(".tab-content"),

    // Mic
    micStartBtn: document.getElementById("mic-start-btn"),
    micStopBtn: document.getElementById("mic-stop-btn"),
    micStatus: document.getElementById("mic-status"),
    micLevel: document.getElementById("mic-level"),

    // Chart
    chartCanvas: document.getElementById("prob-chart"),

    // Verdict
    verdictCard: document.getElementById("verdict-card"),
    verdictText: document.getElementById("verdict-text"),
    riskLevel: document.getElementById("risk-level"),
    confidence: document.getElementById("confidence"),
    fakeProb: document.getElementById("fake-prob"),
    predClass: document.getElementById("pred-class"),
    modelUsed: document.getElementById("model-used"),
    attackType: document.getElementById("attack-type"),
    degRisk: document.getElementById("deg-risk"),
    recAction: document.getElementById("rec-action"),
    spinner: document.getElementById("spinner"),

    // Report
    explanation: document.getElementById("explanation"),

    // Feature risks
    featureRiskPanel: document.getElementById("feature-risk-panel"),
    featureRisks: document.getElementById("feature-risks"),

    // Tech dashboard
    toggleTechBtn: document.getElementById("toggle-tech-btn"),
    techContent: document.getElementById("tech-content"),
    techTabs: document.querySelectorAll(".tech-tab"),
    techTabContents: document.querySelectorAll(".tech-tab-content"),
    terminalOutput: document.getElementById("terminal-output"),
    featuresJson: document.getElementById("features-json"),
    rawJson: document.getElementById("raw-json"),
    reasoningTrace: document.getElementById("reasoning-trace"),

    // Pipeline
    pipelineBtns: document.querySelectorAll(".pipeline-btns .btn"),
    jobStatus: document.getElementById("job-status"),
    jobProgress: document.getElementById("job-progress"),
    jobStatusText: document.getElementById("job-status-text"),
};

let selectedFile = null;
let chart = null;
let currentJobId = null;
let ws = null;
let jobTaskMap = {};

// ------------------------------------------------------------------
// Microphone state (Web Audio API + WAV encoder)
// ------------------------------------------------------------------
let audioCtx = null;
let micStream = null;
let micSource = null;
let micProcessor = null;
let micBuffer = [];
let micChunkTimer = null;
let streamStartTime = null;
let chunkIndex = 0;
let micActive = false;

// ------------------------------------------------------------------
// Utility: WAV encoder
// ------------------------------------------------------------------
function encodeWAV(samples, sampleRate) {
    const buffer = new ArrayBuffer(44 + samples.length * 2);
    const view = new DataView(buffer);

    const writeString = (offset, string) => {
        for (let i = 0; i < string.length; i++) {
            view.setUint8(offset + i, string.charCodeAt(i));
        }
    };

    writeString(0, "RIFF");
    view.setUint32(4, 36 + samples.length * 2, true);
    writeString(8, "WAVE");
    writeString(12, "fmt ");
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, "data");
    view.setUint32(40, samples.length * 2, true);

    let offset = 44;
    for (let i = 0; i < samples.length; i++) {
        let s = Math.max(-1, Math.min(1, samples[i]));
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
        offset += 2;
    }

    return new Blob([view], { type: "audio/wav" });
}

function interleave(input) {
    // input is Float32Array mono
    return input;
}

// ------------------------------------------------------------------
// Chart
// ------------------------------------------------------------------
function initChart() {
    const ctx = els.chartCanvas.getContext("2d");
    chart = new Chart(ctx, {
        type: "line",
        data: {
            datasets: [
                {
                    label: "real",
                    borderColor: "#22c55e",
                    backgroundColor: "rgba(34,197,94,0.1)",
                    data: [],
                    tension: 0.3,
                    pointRadius: 2,
                },
                {
                    label: "fake_synth",
                    borderColor: "#ef4444",
                    backgroundColor: "rgba(239,68,68,0.1)",
                    data: [],
                    tension: 0.3,
                    pointRadius: 2,
                },
                {
                    label: "fake_distort",
                    borderColor: "#f59e0b",
                    backgroundColor: "rgba(245,158,11,0.1)",
                    data: [],
                    tension: 0.3,
                    pointRadius: 2,
                },
                {
                    label: "any fake",
                    borderColor: "#a855f7",
                    backgroundColor: "rgba(168,85,247,0.1)",
                    data: [],
                    tension: 0.3,
                    pointRadius: 2,
                    borderDash: [5, 5],
                },
            ],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            interaction: { mode: "index", intersect: false },
            scales: {
                x: {
                    type: "linear",
                    title: {
                        display: true,
                        text: "Time (s)",
                        color: "#9aa3b2",
                    },
                    grid: { color: "#2d333b" },
                    ticks: { color: "#9aa3b2" },
                },
                y: {
                    min: 0,
                    max: 1.05,
                    title: {
                        display: true,
                        text: "Probability",
                        color: "#9aa3b2",
                    },
                    grid: { color: "#2d333b" },
                    ticks: { color: "#9aa3b2" },
                },
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: "#181b21",
                    titleColor: "#e6e8ec",
                    bodyColor: "#e6e8ec",
                    borderColor: "#2d333b",
                    borderWidth: 1,
                },
            },
        },
    });
}

function addChartPoint(timeSec, probs, fakeProb) {
    if (!chart) return;
    chart.data.datasets[0].data.push({ x: timeSec, y: probs.real });
    chart.data.datasets[1].data.push({ x: timeSec, y: probs.fake_synth });
    chart.data.datasets[2].data.push({ x: timeSec, y: probs.fake_distort });
    chart.data.datasets[3].data.push({ x: timeSec, y: fakeProb });

    // Keep last 60 points and scroll x-axis
    if (chart.data.datasets[0].data.length > 60) {
        chart.data.datasets.forEach((ds) => ds.data.shift());
    }
    const times = chart.data.datasets[0].data.map((p) => p.x);
    chart.options.scales.x.min = Math.max(0, times[0] - 2);
    chart.options.scales.x.max = times[times.length - 1] + 2;
    chart.update("none");
}

// ------------------------------------------------------------------
// API / health
// ------------------------------------------------------------------
async function checkHealth() {
    try {
        const res = await fetch(`${API_URL}/health`, { method: "GET" });
        const data = await res.json();
        els.status.textContent = data.checkpoint_available
            ? "API + model ready"
            : "API ready (mock model)";
        els.status.classList.add("ok");
    } catch (err) {
        els.status.textContent = "API unreachable";
        els.status.classList.add("error");
        showError("Cannot reach API. Is the server running?");
        console.error(err);
    }
}

async function loadSamples() {
    try {
        const res = await fetch(`${API_URL}/samples`);
        const data = await res.json();
        data.samples.forEach((name) => {
            const opt = document.createElement("option");
            opt.value = name;
            opt.textContent = name;
            els.sampleSelect.appendChild(opt);
        });
    } catch (err) {
        console.error("Failed to load samples", err);
    }
}

// ------------------------------------------------------------------
// Error toast
// ------------------------------------------------------------------
function showError(msg) {
    els.errorToast.textContent = msg;
    els.errorToast.classList.remove("hidden");
    setTimeout(() => els.errorToast.classList.add("hidden"), 6000);
}

function clearError() {
    els.errorToast.classList.add("hidden");
}

// ------------------------------------------------------------------
// Tabs
// ------------------------------------------------------------------
function switchTab(tabName) {
    els.tabBtns.forEach((btn) => {
        btn.classList.toggle("active", btn.dataset.tab === tabName);
    });
    els.tabContents.forEach((content) => {
        content.classList.toggle("active", content.id === `tab-${tabName}`);
    });
    if (tabName !== "file") {
        selectedFile = null;
        els.input.value = "";
    }
    if (tabName !== "sample") {
        els.preview.hidden = true;
    }
    updateAnalyzeButton();
}

els.tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => switchTab(btn.dataset.tab));
});

// ------------------------------------------------------------------
// File upload
// ------------------------------------------------------------------
function handleFile(file) {
    selectedFile = file;
    switchTab("file");
    els.preview.src = URL.createObjectURL(file);
    els.preview.hidden = false;
    updateAnalyzeButton();
    resetResults();
}

els.browseBtn.addEventListener("click", () => els.input.click());

els.dropzone.addEventListener("click", (e) => {
    if (
        e.target === els.dropzone ||
        e.target.closest(".dropzone") === els.dropzone
    ) {
        els.input.click();
    }
});

els.dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    els.dropzone.classList.add("dragover");
});

els.dropzone.addEventListener("dragleave", () => {
    els.dropzone.classList.remove("dragover");
});

els.dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    els.dropzone.classList.remove("dragover");
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
});

els.input.addEventListener("change", () => {
    if (els.input.files[0]) handleFile(els.input.files[0]);
});

els.sampleSelect.addEventListener("change", () => {
    selectedFile = null;
    els.input.value = "";
    els.preview.hidden = true;
    updateAnalyzeButton();
    resetResults();
});

function updateAnalyzeButton() {
    const hasFile = selectedFile !== null;
    const hasSample = els.sampleSelect.value !== "";
    els.analyzeBtn.disabled = !(hasFile || hasSample);
}

// ------------------------------------------------------------------
// Microphone streaming (WAV in browser)
// ------------------------------------------------------------------
async function startMic() {
    clearError();
    try {
        micStream = await navigator.mediaDevices.getUserMedia({
            audio: {
                sampleRate: 16000,
                channelCount: 1,
                echoCancellation: false,
                noiseSuppression: false,
                autoGainControl: false,
            },
        });
    } catch (err) {
        showError("Microphone access denied or not available: " + err.message);
        return;
    }

    audioCtx = new (window.AudioContext || window.webkitAudioContext)({
        sampleRate: 16000,
    });
    micSource = audioCtx.createMediaStreamSource(micStream);

    const bufferSize = 4096;
    micProcessor = audioCtx.createScriptProcessor(bufferSize, 1, 1);
    // Mute the mic monitor to avoid feedback; keep the graph alive with a zero-gain node.
    const muteNode = audioCtx.createGain();
    muteNode.gain.value = 0;
    micBuffer = [];
    chunkIndex = 0;
    streamStartTime = Date.now();
    micActive = true;

    micProcessor.onaudioprocess = (e) => {
        if (!micActive) return;
        const data = e.inputBuffer.getChannelData(0);
        micBuffer.push(new Float32Array(data));
        updateMicLevel(data);
    };

    micSource.connect(micProcessor);
    micProcessor.connect(muteNode);
    muteNode.connect(audioCtx.destination);

    // Send a chunk every 3.5 seconds
    micChunkTimer = setInterval(flushMicChunk, 3500);

    els.micStatus.textContent = "Recording… chunks sent every 3.5 s";
    els.micStartBtn.disabled = true;
    els.micStopBtn.disabled = false;
}

function updateMicLevel(data) {
    let sum = 0;
    for (let i = 0; i < data.length; i++) {
        sum += data[i] * data[i];
    }
    const rms = Math.sqrt(sum / data.length);
    const pct = Math.min(100, rms * 300);
    els.micLevel.querySelector("span").style.width = `${pct}%`;
}

function flushMicChunk() {
    if (micBuffer.length === 0) return;

    // Flatten buffer
    const totalLength = micBuffer.reduce((acc, b) => acc + b.length, 0);
    const flat = new Float32Array(totalLength);
    let offset = 0;
    for (const b of micBuffer) {
        flat.set(b, offset);
        offset += b.length;
    }
    micBuffer = [];

    const timeSec = ((Date.now() - streamStartTime) / 1000).toFixed(1);
    els.micStatus.textContent = `Analyzing chunk #${chunkIndex + 1} @ ${timeSec}s`;

    const wavBlob = encodeWAV(flat, audioCtx.sampleRate);
    sendChunk(wavBlob, parseFloat(timeSec));
    chunkIndex++;
}

function stopMic() {
    micActive = false;
    if (micChunkTimer) {
        clearInterval(micChunkTimer);
        micChunkTimer = null;
    }
    if (micProcessor) {
        micProcessor.disconnect();
        micProcessor = null;
    }
    if (micSource) {
        micSource.disconnect();
        micSource = null;
    }
    if (audioCtx && audioCtx.state !== "closed") {
        audioCtx.close();
        audioCtx = null;
    }
    if (micStream) {
        micStream.getTracks().forEach((t) => t.stop());
        micStream = null;
    }
    els.micStatus.textContent = "Recording stopped";
    els.micLevel.querySelector("span").style.width = "0%";
    els.micStartBtn.disabled = false;
    els.micStopBtn.disabled = true;
}

els.micStartBtn.addEventListener("click", startMic);
els.micStopBtn.addEventListener("click", stopMic);

async function sendChunk(blob, timeSec) {
    const form = new FormData();
    form.append("file", blob, `chunk_${chunkIndex}.wav`);
    try {
        const res = await fetch(`${API_URL}/analyze/chunk`, {
            method: "POST",
            body: form,
        });
        if (!res.ok) {
            const err = await res
                .json()
                .catch(() => ({ detail: `HTTP ${res.status}` }));
            throw new Error(err.detail || `HTTP ${res.status}`);
        }
        const result = await res.json();
        addChartPoint(
            timeSec,
            result.class_probs || { real: 0, fake_synth: 0, fake_distort: 0 },
            result.fake_probability || 0,
        );
        renderResult(result, false);
    } catch (err) {
        console.error("Chunk analysis failed", err);
        showError("Chunk analysis failed: " + err.message);
    }
}

// ------------------------------------------------------------------
// Single analysis
// ------------------------------------------------------------------
async function runAnalysis() {
    clearError();
    resetResults();
    els.spinner.classList.remove("hidden");
    els.analyzeBtn.disabled = true;

    try {
        let res;
        if (selectedFile) {
            const form = new FormData();
            form.append("file", selectedFile);
            res = await fetch(`${API_URL}/analyze`, {
                method: "POST",
                body: form,
            });
        } else if (els.sampleSelect.value) {
            els.preview.src = `${API_URL}/samples/${encodeURIComponent(els.sampleSelect.value)}`;
            els.preview.hidden = false;
            res = await fetch(`${API_URL}/analyze/sample`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ sample_name: els.sampleSelect.value }),
            });
        } else {
            throw new Error("No audio selected");
        }

        if (!res.ok) {
            const err = await res
                .json()
                .catch(() => ({ detail: "Unknown error" }));
            throw new Error(err.detail || `HTTP ${res.status}`);
        }

        const result = await res.json();
        renderResult(result, true);
    } catch (err) {
        showError(`Analysis failed: ${err.message}`);
        console.error(err);
    } finally {
        els.spinner.classList.add("hidden");
        updateAnalyzeButton();
    }
}

els.analyzeBtn.addEventListener("click", runAnalysis);

// ------------------------------------------------------------------
// Render results
// ------------------------------------------------------------------
function resetResults() {
    els.verdictCard.classList.add("hidden");
    els.featureRiskPanel.classList.add("hidden");
    els.featureRisks.innerHTML = "";
    els.reasoningTrace.innerHTML = "";
    els.explanation.textContent =
        "Upload or record audio to see the agent's explanation.";
    els.featuresJson.textContent = "—";
    els.rawJson.textContent = "—";
}

function renderFeatureRisks(risks) {
    if (!risks || Object.keys(risks).length === 0) {
        els.featureRiskPanel.classList.add("hidden");
        return;
    }
    els.featureRiskPanel.classList.remove("hidden");
    els.featureRisks.innerHTML = "";
    const sorted = Object.entries(risks).sort((a, b) => b[1] - a[1]);
    sorted.forEach(([name, value]) => {
        const row = document.createElement("div");
        row.className = "risk-row";
        const pct = Math.round(value * 100);
        let color = "var(--ok)";
        if (value > 0.6) color = "var(--danger)";
        else if (value > 0.3) color = "var(--warn)";
        row.innerHTML = `
            <div class="risk-label">
                <span>${name}</span>
                <span class="risk-value">${pct}%</span>
            </div>
            <div class="risk-track">
                <div class="risk-bar" style="width: ${pct}%; background: ${color};"></div>
            </div>
        `;
        els.featureRisks.appendChild(row);
    });
}

function renderResult(result, full = true) {
    const verdict = result.verdict || "UNKNOWN";
    els.verdictText.textContent = verdict;
    els.verdictText.className = `verdict-title verdict-${verdict}`;
    els.riskLevel.textContent = result.risk_level || "—";
    els.confidence.textContent =
        result.confidence !== undefined ? result.confidence : "—";
    els.fakeProb.textContent =
        result.fake_probability !== undefined
            ? result.fake_probability.toFixed(3)
            : "—";
    els.predClass.textContent =
        result.predicted_class !== undefined ? result.predicted_class : "—";
    els.modelUsed.textContent = result.model_used || "n/a";
    els.attackType.textContent = result.attack_type_guess || "n/a";
    els.degRisk.textContent =
        (result.robustness_context &&
            result.robustness_context.degradation_risk) ||
        "—";
    els.recAction.textContent = result.recommended_action || "—";
    els.verdictCard.classList.remove("hidden");

    if (full) {
        els.reasoningTrace.innerHTML = "";
        (result.reasoning_trace || []).forEach((step) => {
            const li = document.createElement("li");
            li.textContent = step;
            els.reasoningTrace.appendChild(li);
        });

        els.explanation.textContent =
            result.explanation || "No explanation available.";

        renderFeatureRisks(result.feature_risks);

        const slimFeatures = { ...result.features };
        delete slimFeatures.mfcc_mean;
        delete slimFeatures.mfcc_std;
        els.featuresJson.textContent = JSON.stringify(slimFeatures, null, 2);

        els.rawJson.textContent = JSON.stringify(result, null, 2);
    }
}

// ------------------------------------------------------------------
// Technical dashboard
// ------------------------------------------------------------------
function toggleTech() {
    const hidden = els.techContent.classList.toggle("hidden");
    els.toggleTechBtn.textContent = hidden ? "Show" : "Hide";
}

els.toggleTechBtn.addEventListener("click", toggleTech);

els.techTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
        els.techTabs.forEach((t) => t.classList.remove("active"));
        els.techTabContents.forEach((c) => c.classList.remove("active"));
        tab.classList.add("active");
        document
            .getElementById(`tech-${tab.dataset.tech}`)
            .classList.add("active");
    });
});

function appendTerminal(text) {
    if (els.terminalOutput.textContent === "No task output yet.") {
        els.terminalOutput.textContent = "";
    }
    els.terminalOutput.textContent += text + "\n";
    els.terminalOutput.scrollTop = els.terminalOutput.scrollHeight;
}

// ------------------------------------------------------------------
// Pipeline task buttons
// ------------------------------------------------------------------
function setJobProgress(running) {
    els.jobStatus.classList.remove("hidden");
    if (running) {
        els.jobProgress.classList.add("indeterminate");
        els.jobProgress.style.width = "100%";
    } else {
        els.jobProgress.classList.remove("indeterminate");
        els.jobProgress.style.width = "100%";
    }
}

async function startTask(task) {
    clearError();
    try {
        const res = await fetch(`${API_URL}/tasks/${task}`, { method: "POST" });
        const data = await res.json();
        currentJobId = data.job_id;
        jobTaskMap[currentJobId] = task;
        els.jobStatus.classList.remove("hidden");
        setJobProgress(true);
        els.jobStatusText.textContent = `${task}: ${data.status} (job ${currentJobId.slice(0, 8)})`;
        els.terminalOutput.textContent = "";
        connectWebSocket(currentJobId);
        showTechTab("terminal");
        if (els.techContent.classList.contains("hidden")) toggleTech();
    } catch (err) {
        showError(`Failed to start ${task}: ${err.message}`);
        console.error(err);
    }
}

function connectWebSocket(jobId) {
    const wsUrl = `${window.location.protocol === "https:" ? "wss:" : "ws:"}//${window.location.host}/ws/${jobId}`;
    ws = new WebSocket(wsUrl);

    ws.onopen = () => {
        setJobProgress(true);
    };

    ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.error) {
            appendTerminal(`[error] ${msg.error}`);
            return;
        }
        if (msg.lines && msg.lines.length) {
            msg.lines.forEach((line) => appendTerminal(line));
        }
        const taskName = jobTaskMap[jobId] || "task";
        els.jobStatusText.textContent = `${taskName}: ${msg.status}`;
        if (msg.status === "completed" || msg.status === "failed") {
            setJobProgress(false);
            appendTerminal(`[${msg.status}] returncode=${msg.returncode}`);
            ws.close();
        }
    };

    ws.onerror = (err) => {
        console.error("WebSocket error", err);
        pollJob(jobId);
    };

    ws.onclose = () => {
        if (els.jobStatusText.textContent.includes("running")) {
            pollJob(jobId);
        }
    };
}

// Fallback polling if WebSocket fails
function taskFromJobId(jobId) {
    return jobTaskMap[jobId] || "task";
}

async function pollJob(jobId) {
    setJobProgress(true);
    const interval = setInterval(async () => {
        try {
            const res = await fetch(`${API_URL}/tasks/${jobId}`);
            const data = await res.json();
            els.jobStatusText.textContent = `${data.task}: ${data.status}`;
            if (data.output && data.output.length) {
                els.terminalOutput.textContent = data.output.join("\n") + "\n";
                els.terminalOutput.scrollTop = els.terminalOutput.scrollHeight;
            }
            if (data.status === "completed" || data.status === "failed") {
                clearInterval(interval);
                setJobProgress(false);
            }
        } catch (err) {
            console.error("Polling failed", err);
            clearInterval(interval);
            setJobProgress(false);
        }
    }, 1000);
}

function showTechTab(name) {
    els.techTabs.forEach((t) =>
        t.classList.toggle("active", t.dataset.tech === name),
    );
    els.techTabContents.forEach((c) =>
        c.classList.toggle("active", c.id === `tech-${name}`),
    );
}

els.pipelineBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
        const task = btn.dataset.task;
        startTask(task);
    });
});

// ------------------------------------------------------------------
// Init
// ------------------------------------------------------------------
initChart();
checkHealth();
loadSamples();
