"""
src/task4_demo/app.py

Task 4 — Interactive Demonstration (Streamlit).

Upload or pick a sample .wav file, run it through the full agentic pipeline
(feature extraction -> Task 1 classifier -> agent's conditional secondary
checks -> threat assessment -> LLM explanation), and see the verdict,
risk level, reasoning trace, and audio features in real time.

Run (from the project root):
    streamlit run src/task4_demo/app.py
"""

import glob
import json
import os
import sys
import tempfile

import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np
import requests
import streamlit as st

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))

API_URL = os.getenv("CERBERUS_API_URL", "http://localhost:8000")

st.set_page_config(page_title="Cerberus — Voice Spoofing Detector", layout="wide")

st.title("🛡️ Cerberus — Agentic AI Voice Spoofing Detector")
st.caption(
    "Upload a voice clip and the agent will extract features, classify it, "
    "autonomously decide whether it needs more evidence, assess threat level, "
    "and explain its verdict in plain language."
)

# Health check against the FastAPI backend
try:
    health = requests.get(f"{API_URL}/health", timeout=2).json()
    if not health.get("checkpoint_available"):
        st.warning(
            "⚠️ No trained Task 1 checkpoint found at `models/task1_classifier.pt` — "
            "the agent is currently running on a **mock heuristic**, not a trained "
            "classifier. Run `python src/task1_classifier/train.py` first for real results."
        )
except requests.RequestException:
    st.error(
        f"❌ Cannot reach Cerberus API at {API_URL}. Start it with: `uvicorn src.api.main:app --reload --port 8000`"
    )
    st.stop()

col1, col2 = st.columns([1, 1])

with col1:
    st.subheader("1. Choose audio")
    uploaded = st.file_uploader("Upload a .wav file", type=["wav"])

    try:
        sample_files = (
            requests.get(f"{API_URL}/samples", timeout=2).json().get("samples", [])
        )
    except requests.RequestException:
        sample_files = []

    sample_choice = st.selectbox(
        "...or pick a bundled sample",
        ["(none)"] + sample_files,
    )

    audio_bytes = None
    audio_path = None
    if uploaded is not None:
        audio_bytes = uploaded.getvalue()
        st.audio(uploaded)
    elif sample_choice != "(none)":
        st.info(f"Will analyze bundled sample: `{sample_choice}`")

    run_btn = st.button(
        "🔍 Analyze",
        type="primary",
        disabled=(uploaded is None and sample_choice == "(none)"),
    )

with col2:
    st.subheader("2. Verdict")
    result_slot = st.empty()

if run_btn:
    with st.spinner("Running agentic pipeline via API..."):
        try:
            if uploaded is not None:
                files = {"file": (uploaded.name, audio_bytes, "audio/wav")}
                response = requests.post(f"{API_URL}/analyze", files=files, timeout=120)
            else:
                response = requests.post(
                    f"{API_URL}/analyze/sample",
                    json={"sample_name": sample_choice},
                    timeout=120,
                )
            response.raise_for_status()
            result = response.json()
        except requests.RequestException as e:
            st.error(f"Pipeline failed: {e}")
            st.stop()

    verdict = result["verdict"]
    risk = result["risk_level"]
    conf = result["confidence"]
    color = {
        "REAL": "green",
        "LIKELY_REAL": "blue",
        "LIKELY_FAKE": "orange",
        "FAKE": "red",
    }.get(verdict, "gray")

    with col2:
        result_slot.markdown(
            f"### Verdict: :{color}[{verdict}]\n"
            f"**Risk level:** {risk}  \n"
            f"**Confidence:** {conf}  \n"
            f"**Model used:** `{result.get('model_used', 'n/a')}`  \n"
            f"**Attack type guess:** {result.get('attack_type_guess') or 'n/a'}  \n"
            f"**Recommended action:** {result.get('recommended_action', 'n/a')}"
        )

        if result.get("ood", {}).get("is_ood"):
            st.warning(f"⚠️ Out-of-distribution sample: {result['ood']['reason']}")

        robustness = result.get("robustness_context") or {}
        if robustness.get("report_available"):
            st.caption(
                f"Robustness context: estimated {robustness.get('estimated_snr_db')} dB SNR, "
                f"expected accuracy {robustness.get('expected_accuracy')}, "
                f"degradation risk {robustness.get('degradation_risk')}"
            )

    st.subheader("3. Agent's reasoning trace (explainability)")
    for i, step in enumerate(result["reasoning_trace"], 1):
        st.markdown(f"**{i}.** {step}")

    st.subheader("4. Plain-language explanation")
    st.info(result.get("explanation", ""))

    st.subheader("5. Extracted acoustic features")
    feat_col1, feat_col2 = st.columns(2)
    with feat_col1:
        st.json(
            {
                k: v
                for k, v in result["features"].items()
                if k not in ("mfcc_mean", "mfcc_std")
            }
        )
    with feat_col2:
        if audio_bytes is not None:
            y, sr = librosa.load(audio_bytes, sr=16000, mono=True)
        else:
            sample_path = os.path.join(_PROJECT_ROOT, "samples", sample_choice)
            y, sr = librosa.load(sample_path, sr=16000, mono=True)
        fig, ax = plt.subplots(figsize=(6, 3))
        S = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=80)
        S_db = librosa.power_to_db(S, ref=np.max)
        img = librosa.display.specshow(S_db, sr=sr, x_axis="time", y_axis="mel", ax=ax)
        ax.set_title("Mel Spectrogram")
        fig.colorbar(img, ax=ax, format="%+2.0f dB")
        st.pyplot(fig)

    with st.expander("Raw JSON output"):
        st.code(json.dumps(result, indent=2), language="json")
