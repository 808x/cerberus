"""
src/task3_robustness/robustness_eval.py

Task 3 — Robustness evaluation for the 3-class adversarial classifier.

Evaluates how well the trained Task 1 model holds up under:
  1. Clean baseline
  2. Additive noise at several SNR levels
  3. Reverberation
  4. Dynamic range compression / clipping
  5. Band-pass filtering (telephone quality)
  6. Pitch shifting
  7. Time stretching
  8. Unseen-attack generalization (optional)

Output:
  reports/task3_robustness.json
"""

import argparse
import json
import os
import shutil
import sys

import joblib
import librosa
import numpy as np
import soundfile as sf
import torch
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from tqdm import tqdm

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "task1_classifier"))
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "task0_cloning"))

from augmentations import (  # noqa: E402
    add_noise,
    add_reverb,
    bandpass_filter,
    compress_clip,
    pitch_shift,
    time_stretch,
)
from dataset import apply_scaler  # noqa: E402
from feature_extraction import extract_features, feature_vector  # noqa: E402
from model import build_model  # noqa: E402

TARGET_SR = 16000
CLASS_NAMES = ["real", "fake_synth", "fake_distort"]
LABEL_DIRS = {"real": 0, "fake_synth": 1, "fake_distort": 2}


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data-root", default="data")
    p.add_argument("--checkpoint", default="models/task1_classifier.pt")
    p.add_argument("--out", default="reports/task3_robustness.json")
    p.add_argument("--tmp-dir", default="reports/_tmp_perturbed")
    p.add_argument("--n-jobs", type=int, default=-1)
    return p.parse_args()


def load_model(checkpoint_path):
    ckpt = torch.load(checkpoint_path, map_location="cpu")
    model = build_model(
        in_dim=ckpt["in_dim"],
        hidden=ckpt["hidden"],
        dropout=ckpt.get("dropout", 0.4),
        n_classes=ckpt.get("n_classes", 3),
    )
    model.load_state_dict(ckpt["state_dict"])
    model.eval()
    return model, ckpt["scaler"]


def gather_data(data_root):
    import glob

    paths, labels = [], []
    for subdir, label in LABEL_DIRS.items():
        full_dir = os.path.join(data_root, subdir)
        if not os.path.isdir(full_dir):
            continue
        files = sorted(glob.glob(os.path.join(full_dir, "*.wav")))
        paths.extend(files)
        labels.extend([label] * len(files))
    return paths, np.array(labels, dtype=np.int64)


def _extract_one(path):
    try:
        feats = extract_features(path)
        return feature_vector(feats)
    except Exception as e:
        print(f"[skip] {path}: {e}")
        return None


def predict_paths(model, scaler, paths, n_jobs=-1, desc="Extracting"):
    """Return predictions and probabilities for a list of audio paths."""
    X = joblib.Parallel(n_jobs=n_jobs, verbose=0)(
        joblib.delayed(_extract_one)(p) for p in tqdm(paths, desc=desc, unit="file")
    )
    X = [v for v in X if v is not None]
    if len(X) != len(paths):
        raise RuntimeError("Some features could not be extracted.")
    X = np.stack(X)
    X = apply_scaler(X, scaler)
    with torch.no_grad():
        logits = model(torch.tensor(X, dtype=torch.float32))
        probs = torch.softmax(logits, dim=1).numpy()
    preds = probs.argmax(axis=1)
    return preds, probs


def evaluate(labels, preds):
    acc = accuracy_score(labels, preds)
    _, _, f1, _ = precision_recall_fscore_support(
        labels, preds, average="weighted", zero_division=0
    )
    _, _, per_class_f1, _ = precision_recall_fscore_support(
        labels, preds, labels=[0, 1, 2], zero_division=0
    )
    return {
        "accuracy": round(float(acc), 4),
        "weighted_f1": round(float(f1), 4),
        "per_class_f1": {
            name: round(float(per_class_f1[i]), 4) for i, name in enumerate(CLASS_NAMES)
        },
        "n": len(labels),
    }


def write_perturbed(paths, labels, transform_fn, out_subdir, desc="Perturbing"):
    """Apply transform_fn to each path and write to out_subdir. Returns new paths."""
    os.makedirs(out_subdir, exist_ok=True)
    new_paths = []
    for i, p in enumerate(tqdm(paths, desc=desc, unit="file")):
        y, sr = librosa.load(p, sr=TARGET_SR, mono=True)
        y_out = transform_fn(y)
        # Normalize peak
        peak = np.max(np.abs(y_out))
        if peak > 0:
            y_out = y_out / peak
        out_path = os.path.join(out_subdir, f"{i:05d}.wav")
        sf.write(out_path, y_out, TARGET_SR)
        new_paths.append(out_path)
    return new_paths


def main():
    args = parse_args()
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    if os.path.exists(args.tmp_dir):
        shutil.rmtree(args.tmp_dir)

    print("Loading model...")
    model, scaler = load_model(args.checkpoint)

    print("Gathering data...")
    paths, labels = gather_data(args.data_root)
    print(f"  {len(paths)} samples")

    report = {}
    pbar = tqdm(total=11, desc="Robustness evaluation", unit="condition")

    # 1. Clean baseline
    print("Clean baseline...")
    preds, _ = predict_paths(model, scaler, paths, desc="Clean baseline")
    report["clean_baseline"] = evaluate(labels, preds)
    pbar.update(1)

    # 2. Noise robustness
    for snr in [20, 10, 5, 0]:
        print(f"Noise @ {snr} dB SNR...")
        noisy_paths = write_perturbed(
            paths,
            labels,
            lambda y: add_noise(y, TARGET_SR, snr, np.random.default_rng(42)),
            os.path.join(args.tmp_dir, f"noise_{snr}db"),
            desc=f"Noise {snr}dB",
        )
        preds, _ = predict_paths(model, scaler, noisy_paths, desc=f"Noise {snr}dB")
        report[f"noise_snr_{snr}db"] = evaluate(labels, preds)
        pbar.update(1)

    # 3. Reverb
    print("Reverb...")
    reverb_paths = write_perturbed(
        paths,
        labels,
        lambda y: add_reverb(y, TARGET_SR, np.random.default_rng(42)),
        os.path.join(args.tmp_dir, "reverb"),
        desc="Reverb",
    )
    preds, _ = predict_paths(model, scaler, reverb_paths, desc="Reverb")
    report["reverb"] = evaluate(labels, preds)
    pbar.update(1)

    # 4. Compression / clipping
    print("Compression...")
    comp_paths = write_perturbed(
        paths,
        labels,
        lambda y: compress_clip(y, TARGET_SR, np.random.default_rng(42)),
        os.path.join(args.tmp_dir, "compression"),
        desc="Compression",
    )
    preds, _ = predict_paths(model, scaler, comp_paths, desc="Compression")
    report["compression"] = evaluate(labels, preds)
    pbar.update(1)

    # 5. Band-pass filter
    print("Band-pass filter...")
    bp_paths = write_perturbed(
        paths,
        labels,
        lambda y: bandpass_filter(y, TARGET_SR),
        os.path.join(args.tmp_dir, "bandpass"),
        desc="Band-pass",
    )
    preds, _ = predict_paths(model, scaler, bp_paths, desc="Band-pass")
    report["bandpass"] = evaluate(labels, preds)
    pbar.update(1)

    # 6. Pitch shift
    print("Pitch shift...")
    ps_paths = write_perturbed(
        paths,
        labels,
        lambda y: pitch_shift(y, TARGET_SR, 2.0),
        os.path.join(args.tmp_dir, "pitch_shift"),
        desc="Pitch shift",
    )
    preds, _ = predict_paths(model, scaler, ps_paths, desc="Pitch shift")
    report["pitch_shift_up"] = evaluate(labels, preds)
    pbar.update(1)

    # 7. Time stretch
    print("Time stretch...")
    ts_paths = write_perturbed(
        paths,
        labels,
        lambda y: time_stretch(y, TARGET_SR, 1.15),
        os.path.join(args.tmp_dir, "time_stretch"),
        desc="Time stretch",
    )
    preds, _ = predict_paths(model, scaler, ts_paths, desc="Time stretch")
    report["time_stretch"] = evaluate(labels, preds)
    pbar.update(1)

    # 8. Feature-space adversarial noise
    print("Feature-space adversarial noise...")
    X_clean = []
    for p in tqdm(paths, desc="Feature adv clean", unit="file"):
        feats = extract_features(p)
        X_clean.append(feature_vector(feats))
    X_clean = apply_scaler(np.stack(X_clean), scaler)
    rng = np.random.default_rng(42)
    epsilon = 0.2
    X_adv = X_clean + rng.normal(0, epsilon, size=X_clean.shape)
    with torch.no_grad():
        logits = model(torch.tensor(X_adv, dtype=torch.float32))
        preds = logits.argmax(dim=1).cpu().numpy()
    report["feature_adversarial_noise"] = evaluate(labels, preds)
    pbar.update(1)
    pbar.close()

    print(json.dumps(report, indent=2))
    with open(args.out, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\nSaved robustness report to {args.out}")


if __name__ == "__main__":
    main()
