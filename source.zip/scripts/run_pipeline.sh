#!/usr/bin/env bash
# Runs the full pipeline end-to-end from a clean checkout.
# Usage: bash scripts/run_pipeline.sh [quick|xtts]
set -e
MODE="${1:-quick}"

echo "== 1/5 Installing dependencies =="
pip install -r requirements.txt

echo "== 2/5 Generating dataset (mode=$MODE) =="
python src/task0_cloning/generate_dataset.py --mode "$MODE"

echo "== 3/5 Training Task 1 classifier =="
python src/task1_classifier/train.py

echo "== 4/5 Evaluating Task 1 classifier =="
python src/task1_classifier/evaluate.py

echo "== 5/5 Running robustness evaluation (Task 3) =="
python src/task3_robustness/robustness_eval.py

echo ""
echo "All done. Launch the demo with:"
echo "  streamlit run src/task4_demo/app.py"
