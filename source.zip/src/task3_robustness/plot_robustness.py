"""
src/task3_robustness/plot_robustness.py

Reads reports/task3_robustness.json and creates a summary bar chart of
accuracy across all tested perturbations.
"""

import argparse
import json

import matplotlib


matplotlib.use("Agg")
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--report", default="reports/task3_robustness.json")
    p.add_argument("--out", default="reports/task3_robustness.png")
    return p.parse_args()


def main():
    args = parse_args()
    with open(args.report, "r") as f:
        report = json.load(f)

    names = []
    accuracies = []
    for key in [
        "clean_baseline",
        "noise_snr_20db",
        "noise_snr_10db",
        "noise_snr_5db",
        "noise_snr_0db",
        "reverb",
        "compression",
        "bandpass",
        "pitch_shift_up",
        "time_stretch",
        "feature_adversarial_noise",
    ]:
        if key in report and isinstance(report[key], dict):
            names.append(key.replace("_", " "))
            accuracies.append(report[key]["accuracy"])

    plt.figure(figsize=(10, 5))
    bars = plt.bar(names, accuracies, color="steelblue")
    plt.axhline(1.0, color="green", linestyle="--", alpha=0.5, label="perfect")
    plt.axhline(0.5, color="red", linestyle="--", alpha=0.5, label="random (3-class)")
    plt.ylim(0, 1.05)
    plt.ylabel("Accuracy")
    plt.title("Task 3 — Classifier Robustness Across Perturbations")
    plt.xticks(rotation=45, ha="right")
    for bar, acc in zip(bars, accuracies):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.02,
            f"{acc:.2f}",
            ha="center",
            va="bottom",
            fontsize=8,
        )
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.02,
            f"{acc:.2f}",
            ha="center",
            va="bottom",
            fontsize=8,
        )
    plt.tight_layout()
    plt.savefig(args.out, dpi=150)
    plt.close()
    print(f"Saved plot to {args.out}")


if __name__ == "__main__":
    main()
