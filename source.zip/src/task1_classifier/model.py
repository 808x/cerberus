"""
src/task1_classifier/model.py

Task 1 — Anti-Spoofing Classifier architecture.

Three-class MLP for the adversarial dataset:
  0 = real
  1 = fake_synthetic
  2 = fake_distorted

The model outputs raw logits; CrossEntropyLoss is applied outside.
"""

import torch
import torch.nn as nn


class SpoofClassifier(nn.Module):
    """MLP classifier for real vs. synthetic vs. distorted-real speech."""

    def __init__(
        self, in_dim: int, hidden: int = 256, dropout: float = 0.4, n_classes: int = 3
    ):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.BatchNorm1d(hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2),
            nn.BatchNorm1d(hidden // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden // 2, n_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def build_model(
    in_dim: int, hidden: int = 256, dropout: float = 0.4, n_classes: int = 3
) -> SpoofClassifier:
    return SpoofClassifier(
        in_dim=in_dim, hidden=hidden, dropout=dropout, n_classes=n_classes
    )
