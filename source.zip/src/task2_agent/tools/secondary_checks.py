"""
tools/secondary_checks.py

These tools are only invoked by the agent when the primary classifier score
is "ambiguous" (see thresholds in config.yaml). This is what makes the
workflow AGENTIC rather than a fixed pipeline: the agent decides whether it
needs more evidence before committing to a verdict.
"""

import json
import os
from typing import Optional

import numpy as np
from tools.feature_extraction import AudioFeatures


def noise_robustness_check(features: AudioFeatures) -> dict:
    """
    Heuristic: if silence_ratio is unusually high or duration is very short,
    the primary classifier's confidence is less trustworthy (not enough
    signal). Flags that for the reasoning agent to factor in.
    """
    reliable = features.silence_ratio < 0.5 and features.duration_sec > 1.0
    return {
        "check": "noise_robustness",
        "reliable_sample": reliable,
        "reason": (
            "Sufficient voiced audio to trust classifier confidence."
            if reliable
            else "High silence ratio or very short clip - classifier confidence may be unreliable."
        ),
    }


def known_attack_signature_check(features: AudioFeatures, signatures_path: str) -> dict:
    """
    Compares extracted features against a small library of known spoofing
    attack fingerprints (e.g. typical vocoder artifact ranges). Start this
    file empty/mock and grow it as your team characterizes attack types
    during Task 3 (Robustness Evaluation).
    """
    if not os.path.exists(signatures_path):
        return {
            "check": "known_attack_signature",
            "matched_attack_type": None,
            "reason": "No signature library found yet - skipping match.",
        }

    with open(signatures_path, "r") as f:
        signatures = json.load(f)

    for sig in signatures:
        hf_range = sig.get("high_freq_energy_ratio_range", [0, 1])
        flat_range = sig.get("spectral_flatness_range", [0, 1])
        if (
            hf_range[0] <= features.high_freq_energy_ratio <= hf_range[1]
            and flat_range[0] <= features.spectral_flatness_mean <= flat_range[1]
        ):
            return {
                "check": "known_attack_signature",
                "matched_attack_type": sig["name"],
                "reason": f"Feature profile matches known '{sig['name']}' signature.",
            }

    return {
        "check": "known_attack_signature",
        "matched_attack_type": None,
        "reason": "No match against known attack signatures - possibly a novel/unseen attack.",
    }


def out_of_distribution_check(
    features: AudioFeatures,
    scaler_path: Optional[str] = None,
    z_threshold: float = 4.0,
    percentile: float = 90.0,
    full_feature_vector: Optional[np.ndarray] = None,
) -> dict:
    """
    Flags samples that are far from the training distribution. If the feature
    vector is too many standard deviations away from the fitted scaler, the
    classifier's output is not trustworthy and the agent should return
    INSUFFICIENT_EVIDENCE rather than a forced verdict.

    Uses the percentile z-score (default 90th) rather than the single maximum
    dimension, so one outlier MFCC coefficient doesn't reject an otherwise
    normal sample.

    Args:
        features: extracted audio features (used for heuristic checks).
        scaler_path: path to the JSON scaler saved by Task 1 training.
            If None, falls back to simple heuristic checks.
        z_threshold: how many standard deviations away counts as OOD.
        percentile: which percentile of per-dimension z-scores to check.
        full_feature_vector: optional 224-dim classifier feature vector. If
            provided, used for the scaler-based z-score check instead of the
            80-dim MFCC summary from `features`.
    """
    reasons = []
    is_ood = False

    # Heuristic OOD signals (always checked)
    if features.duration_sec < 0.5:
        is_ood = True
        reasons.append(f"duration ({features.duration_sec:.2f}s) is below 0.5s")

    if features.silence_ratio > 0.8:
        is_ood = True
        reasons.append(f"silence_ratio ({features.silence_ratio:.2f}) is above 0.8")

    if features.pitch_mean <= 0.0:
        is_ood = True
        reasons.append("no detectable pitch (likely non-speech or silence)")

    # Scaler-based Mahalanobis-style check
    max_z = None
    if scaler_path and os.path.exists(scaler_path):
        try:
            with open(scaler_path, "r") as f:
                scaler = json.load(f)
            mean = scaler.get("mean")
            std = scaler.get("std")
            if mean is not None and std is not None:
                if full_feature_vector is not None:
                    x = full_feature_vector.tolist()
                else:
                    x = features.mfcc_mean + features.mfcc_std
                if len(x) == len(mean) == len(std):
                    z_scores = sorted(
                        abs((x[i] - mean[i]) / (std[i] if std[i] > 1e-8 else 1e-8))
                        for i in range(len(x))
                    )
                    max_z = z_scores[-1]
                    idx = int(round((percentile / 100.0) * len(z_scores))) - 1
                    idx = max(0, min(len(z_scores) - 1, idx))
                    pct_z = z_scores[idx]
                    if pct_z > z_threshold:
                        is_ood = True
                        reasons.append(
                            f"feature vector's {percentile:.0f}th-percentile z-score is "
                            f"{pct_z:.1f} (threshold {z_threshold}, max {max_z:.1f})"
                        )
        except (json.JSONDecodeError, OSError):
            pass

    if is_ood:
        return {
            "check": "out_of_distribution",
            "is_ood": True,
            "max_z_score": round(max_z, 2) if max_z is not None else None,
            "reason": "Sample is out-of-distribution: " + "; ".join(reasons) + ".",
        }

    return {
        "check": "out_of_distribution",
        "is_ood": False,
        "max_z_score": round(max_z, 2) if max_z is not None else None,
        "reason": "Sample features fall within the expected distribution.",
    }
