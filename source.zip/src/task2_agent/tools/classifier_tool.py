"""
tools/classifier_tool.py

Wraps Task 1's trained 3-class anti-spoofing classifier as a callable "tool"
for the agent.

The model outputs probabilities for:
  0 = real
  1 = fake_synthetic
  2 = fake_distorted

For backward compatibility with the agent's binary reasoning, we expose:
  - fake_probability = P(fake_synthetic) + P(fake_distorted)
  - class_probs = full 3-class distribution
  - predicted_class = argmax class
  - feature_attribution = gradient*input attribution per feature for the predicted class
  - feature_risks = heuristic 0-1 risk scores for key interpretable features
"""

import os
import sys
from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np
import torch

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "task1_classifier"))

from feature_extraction import (  # noqa: E402
    extract_features,
    feature_names,
    feature_vector,
)

_MODEL = None
_SCALER = None
_FEATURE_NAMES = None
_IN_DIM = None
_HIDDEN = None
_DROPOUT = None


@dataclass
class ClassifierResult:
    fake_probability: float  # 0.0 = real, 1.0 = any kind of fake
    class_probs: dict
    predicted_class: int
    model_name: str
    feature_attribution: Optional[Dict[str, float]] = None
    feature_risks: Optional[Dict[str, float]] = None


def _load_real_model(checkpoint_path: str):
    """Attempt to load the real Task 1 checkpoint. Returns model or None."""
    global _MODEL, _SCALER, _FEATURE_NAMES, _IN_DIM, _HIDDEN, _DROPOUT
    if _MODEL is not None:
        return _MODEL
    if not os.path.exists(checkpoint_path):
        return None

    from model import build_model  # noqa: E402

    ckpt = torch.load(checkpoint_path, map_location="cpu")
    _IN_DIM = ckpt["in_dim"]
    _HIDDEN = ckpt.get("hidden", 128)
    _DROPOUT = ckpt.get("dropout", 0.3)
    n_classes = ckpt.get("n_classes", 1)

    model = build_model(
        in_dim=_IN_DIM, hidden=_HIDDEN, dropout=_DROPOUT, n_classes=n_classes
    )
    model.load_state_dict(ckpt["state_dict"])
    model.eval()

    _MODEL = model
    _SCALER = ckpt["scaler"]
    _FEATURE_NAMES = feature_names()
    return _MODEL


def _compute_feature_attribution(
    x: torch.Tensor, predicted_class: int
) -> Dict[str, float]:
    """
    Gradient * input attribution for the predicted class.
    Returns a dict of feature_name -> attribution score, sorted by magnitude.
    """
    if _MODEL is None or _FEATURE_NAMES is None:
        return {}

    x_input = x.clone().detach().requires_grad_(True)
    logits = _MODEL(x_input)
    target_logit = logits[0, predicted_class]
    target_logit.backward()

    # Gradient * input attribution
    attr = (x_input.grad * x_input).squeeze(0).detach().cpu().numpy()
    named = {name: float(attr[i]) for i, name in enumerate(_FEATURE_NAMES)}
    # Return top 15 by absolute magnitude
    sorted_items = sorted(named.items(), key=lambda kv: abs(kv[1]), reverse=True)[:15]
    return dict(sorted_items)


def _compute_feature_risks(feats: Dict[str, float]) -> Dict[str, float]:
    """
    Heuristic per-feature fake-risk scores (0 = real-like, 1 = fake-like).
    These are interpretable acoustic cues, not model probabilities.
    """
    risks = {}

    # Synthetic/vocoded audio tends to have flatter spectra
    flatness = feats.get("spectral_flatness_mean", 0.0)
    if flatness < 0.03:
        risks["spectral_flatness"] = 0.0
    elif flatness < 0.08:
        risks["spectral_flatness"] = 0.3
    elif flatness < 0.15:
        risks["spectral_flatness"] = 0.6
    else:
        risks["spectral_flatness"] = 0.9

    # Unnatural high-frequency energy is common in TTS/vocoder artifacts
    hf = feats.get("high_freq_energy_ratio", 0.0)
    if hf < 0.05:
        risks["high_freq_energy"] = 0.0
    elif hf < 0.12:
        risks["high_freq_energy"] = 0.3
    elif hf < 0.25:
        risks["high_freq_energy"] = 0.6
    else:
        risks["high_freq_energy"] = 0.9

    # Very low pitch jitter can indicate overly smooth synthetic pitch
    jitter = feats.get("pitch_jitter", 0.0)
    if jitter < 1.5:
        risks["pitch_jitter"] = 0.5
    elif jitter < 4.0:
        risks["pitch_jitter"] = 0.2
    else:
        risks["pitch_jitter"] = 0.0

    # Too much silence = unreliable, not necessarily fake
    silence = feats.get("silence_ratio", 0.0)
    if silence > 0.7:
        risks["silence_ratio"] = 0.7
    elif silence > 0.5:
        risks["silence_ratio"] = 0.4
    else:
        risks["silence_ratio"] = 0.0

    # Quantized/pitch-corrected voices sound robotic
    quant = feats.get("pitch_quantization_score", 0.0)
    if quant > 0.4:
        risks["pitch_quantization"] = 0.8
    elif quant > 0.2:
        risks["pitch_quantization"] = 0.4
    else:
        risks["pitch_quantization"] = 0.0

    # Harmonic-to-noise ratio: very low HNR suggests heavy distortion/noise
    hnr = feats.get("hnr_db", 30.0)
    if hnr < 5:
        risks["hnr_db"] = 0.8
    elif hnr < 15:
        risks["hnr_db"] = 0.4
    else:
        risks["hnr_db"] = 0.0

    return risks


def _mock_predict(audio_path: str) -> ClassifierResult:
    """
    Placeholder scoring heuristic used ONLY if no trained Task 1 checkpoint
    is found yet. Uses a few cheap features.
    """
    feats = extract_features(audio_path)
    score = 0.0
    score += min(feats["spectral_flatness_mean"] * 5, 0.4)
    score += min(feats["high_freq_energy_ratio"] * 2, 0.3)
    score += 0.1 if feats["pitch_jitter"] < 2.0 else 0.0
    score = max(0.0, min(1.0, score))
    return ClassifierResult(
        fake_probability=score,
        class_probs={"real": 1 - score, "fake_synth": score, "fake_distort": 0.0},
        predicted_class=1 if score >= 0.5 else 0,
        model_name="mock_heuristic",
        feature_risks=_compute_feature_risks(feats),
    )


def predict(
    audio_path: str, checkpoint_path: str = "models/task1_classifier.pt"
) -> ClassifierResult:
    model = _load_real_model(checkpoint_path)

    if model is not None:
        feats = extract_features(audio_path)
        x = feature_vector(feats)
        mean = np.array(_SCALER["mean"], dtype=np.float32)
        std = np.array(_SCALER["std"], dtype=np.float32)
        x_scaled = (x - mean) / std
        x_tensor = torch.tensor(x_scaled, dtype=torch.float32).unsqueeze(0)

        with torch.no_grad():
            logit = model(x_tensor)
            probs = torch.softmax(logit, dim=1).squeeze(0).numpy()

        class_names = ["real", "fake_synth", "fake_distort"]
        class_probs = {name: float(probs[i]) for i, name in enumerate(class_names)}
        predicted_class = int(probs.argmax())
        fake_prob = float(probs[1] + probs[2])

        # Feature attribution requires a forward+backward pass
        attribution = _compute_feature_attribution(
            torch.tensor(x_scaled, dtype=torch.float32).unsqueeze(0), predicted_class
        )
        risks = _compute_feature_risks(feats)

        return ClassifierResult(
            fake_probability=fake_prob,
            class_probs=class_probs,
            predicted_class=predicted_class,
            model_name="task1_3class_mlp",
            feature_attribution=attribution,
            feature_risks=risks,
        )

    return _mock_predict(audio_path)
